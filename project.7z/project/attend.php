<?php
require "designt.php";
include("config.php");

//use session to get data
$tid = $_SESSION["id"];

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;

//set the value to null
$todaydate_err = $todaydate = $attdate =  null;


//get data from table coursedetail
 $course = mysqli_query($link,"SELECT coursedetail.lecturerid, coursedetail.courseid FROM coursedetail JOIN lecturer ON lecturer.lecturerid = coursedetail.lecturerid WHERE lecturer.lecturerid ='$tid'")or die( mysqli_error($link));
 $row1 = mysqli_fetch_row($course);

//check if has select data or not
    if(empty($_POST["todaydate"]))
    {
        $todaydate_err = "Please select a todaydate.";
    }

}

//bind the coursed id and the class section
if(isset($_POST['course_id']))
{
    echo '<option value="">Select Section</option>';
    $sectionGet = mysqli_query($link,"SELECT DISTINCT(section) from coursedetail where courseid='$_POST[course_id]' ") or die(mysqli_error($link));
    $sectionData = mysqli_fetch_row($sectionGet);

    if(!empty($sectionData))
    {
        do{
            //$sectionArr +=array($sectionData[0]);
            ?>
                <option value="<?php echo $sectionData[0];?>"><?php echo $sectionData[0];?></option>
            <?php
            $sectionData = mysqli_fetch_row($sectionGet);
        }while($sectionData);
                    
    }
                
}
?>
<!-- Function binding -->
<script type="text/javascript">
function FetchSection(courid){
    
    $('#section').html('');
    $.ajax({
      type:'post',
      url: 'attend.php',
      data : { course_id : courid},
      success : function(data){
         $('#section').html(data);
      }

    })
    //alert(cid);
}

</script>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student attendent list</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <style>
        .Pro{text-align: center; font-size: 20px;}
        .ab{ text-align: center;font-size: 25px;}
        .word{text-align: center; font-size: 20px;margin-left: auto;margin-right: auto;}
		        .wrapper{ width: 400px; 
                padding: 20px;
				margin-top:50px;
				margin-left:570px;}
    </style>
</head>
<body>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="margin: 20px; font-family: Bookman, URW Bookman L, serif;">
	<div class="wrapper">
        <h2>Attendance</h2>  
    <div class="form-group">
        <label>Attend date:</label>
        <input type="date" name="todaydate" id="todaydate" max="<?php $today = date('Y-m-d'); echo $today; ?>" value="<?php $today = date('Y-m-d'); echo $today;?>" class="form-linktrol <?php echo (!empty($todaydate_err)) ? 'is-invalid' : ''; ?>" >
        <span class="invalid-feedback"><?php echo $todaydate_err; ?></span>
    </div>
    <div class="form-group">
        <label for="Course">Course</label>
        <select class="form-control" name="courseid" id="courseid" onchange="FetchSection(this.value)" required>
            <option value="">Select Course</option>   
                <?php 
                $sql=mysqli_query($link,"SELECT DISTINCT courseid from coursedetail WHERE lecturerid = '$tid'");
                while($row=mysqli_fetch_array($sql))
                {
                ?>
                    <option value="<?php echo htmlentities($row['0']);?>"><?php echo htmlentities($row['0']);?></option>
                <?php } ?>
        </select> 
    </div>  
    <div class="form-group">
        <label for="Section">Section</label>
        <select class="form-control" name="section" id="section" required>
            <option value="">Select Section</option>
        </select> 
    </div>
    <div>
        <input type = "submit" name="generate" class="btn btn-warning" value="Generate QR code">
        <input type = "submit" name="stop" class="btn btn-warning" value="Stop QR code">
    </div>
	

<?php
    //when click generate
    if(isset($_POST['generate']))
    {
        //when qrcode open it will set to 1
        $open = "1";
        $courseid = $_POST['courseid'];
        $section = $_POST['section'];
        $_SESSION['section'] = $section;
        $_SESSION['courseid'] = $courseid;

        //get and store today date
        $date = $_POST['todaydate'];
        $_SESSION['date'] = $date;

        //get data from table attend
        $att = mysqli_query($link,"SELECT *  FROM attend WHERE courseid = '$courseid' AND date='$date' AND section = '$section'")or die( mysqli_error($link));
        $attend = mysqli_fetch_row($att);

        //if don't has data match as the attend it will become null
        //if null
        if(empty($attend))
        {
            $std = mysqli_query($link,"SELECT *  FROM enrolledcourse WHERE courseid = '$courseid' AND section = '$section'")or die( mysqli_error($link));
            $student = mysqli_fetch_row($std);

            if(!empty($student))
            {
                do
                {
                    $insert = mysqli_query($link, "INSERT INTO attend (studentid, courseid, section, date, present, absent) VALUES ('$student[0]', '$courseid', '$section', '$date', null, null)");
                    $student = mysqli_fetch_row($std);
                }while($student);
            }    
        }
?>
<div>
    <?php
        $op = mysqli_real_escape_string($link, $open);
        $cid = mysqli_real_escape_string($link, $courseid);
        $sec = mysqli_real_escape_string($link, $section);
    ?>
</div>
    <?php

            //update the date into qrcode table
            $update = mysqli_query($link, "UPDATE qrcode SET open='$open',TodayDate='$date' WHERE courseid='$courseid' AND section='$section'")or die( mysqli_error($link));
            echo "<br />Date: ".$date;
            echo "<br />Course ID: ".$courseid;
            echo "<br />Section: ".$section;
            echo "<br />Has Start Showing the QR code.";
        }

        //when click stop button
        if(isset($_POST['stop']))
        {
            $open = "0";
            $courseid = $_POST['courseid'];
            $section = $_POST['section'];

            //get and store today date
            $date = $_POST['todaydate'];

            //update the date into qrcode table
            $update = mysqli_query($link, "UPDATE qrcode SET open='$open' WHERE courseid='$courseid' AND section='$section'")or die( mysqli_error($link));

            include_once("checking.php");
    ?>
    <div>
        <?php
            //echo which section and course qrcode is open
            echo "<br />Date: ".$date;
            echo "<br />Course ID: ".$courseid;
            echo "<br />Section: ".$section;
            echo "<br />Has Stop Showing the QR code.";
            ?>
    </div>
    <?php

        }
    ?>
</div>
</body>
</html>