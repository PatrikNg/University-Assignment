<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'attendsystem');


//connect to the phpmyadmin
$conn=mysqli_connect("localhost","root",'');
//check the connection
if(!$conn){
	die("connection error".mysqli_error($conn));
}
//searching for this database
$db=mysqli_select_db($conn,"attendsystem");

//checking the searching database is created or not
if(empty($db)){
	//if not found then create
	//create database
	$create = "CREATE DATABASE attendsystem";
	//checking whether database is created successfully or not
	if(mysqli_query($conn,$create)){
		
		/* Attempt to connect to MySQL database */
	$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
	// Check connection
	if($link === false){
		die("ERROR: Could not connect. " . mysqli_connect_error($link));
	}
	
	
	//select all from table
	$table="SELECT * FROM student";
	//checking table if no then create
	if(!mysqli_query($link,$table)){

		$create1="CREATE TABLE student(
		id int(11) NOT NULL AUTO_INCREMENT UNIQUE KEY,
		studentid varchar(50) NOT NULL PRIMARY KEY,
		name varchar(50) NOT NULL,
		password varchar(255) NOT NULL,
		phone varchar(255) NOT NULL,
		address varchar(255) NOT NULL,
		international varchar(255) NOT NULL,
		email varchar(255) NOT NULL,
		enrollmentyear date NOT NULL,
		gender varchar(6) NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create1)){
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table2="SELECT * FROM lecturer";
	if(!mysqli_query($link,$table2)){

		$create2="CREATE TABLE lecturer(
		id int(11) NOT NULL AUTO_INCREMENT UNIQUE KEY,
		lecturerid varchar(10) NOT NULL PRIMARY KEY,
		name varchar(50) NOT NULL,
		password varchar(255) NOT NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create2)){

			//insert data into lecturer table
			$insertData =
			"INSERT INTO lecturer VALUES
			('','l1','David','lecture'),
			('','l2','John','lecture'),
			('','l3','Thomas','lecture'),
			('','l4','Sarasvathi','lecture'),
			('','l5','Bobby','lecture')";
			if(mysqli_query($link,$insertData)){
				
			}
			else{
				echo mysqli_error($link);
			}
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table3="SELECT * FROM course";
	if(!mysqli_query($link,$table3)){

		$create3="CREATE TABLE course(
		courseid varchar(50) NOT NULL PRIMARY KEY,
		coursename varchar(50) NOT NULL,
		courseprice float(11) NOT NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create3)){
						
			//insert data into course table
			$insertData2 =
			"INSERT INTO course VALUES
			('IBM4202','WEB PROGRAMMING WITH PHP','2000.00'),
			('ITE4204','COMPUTATIONAL MODELLING AND SIMULATION','2000.00'),
			('ITM4202','IT PROJECT MANAGEMENT','2000.00'),
			('PRG3204','WEB APPLICATION DEVELOPMENT','2000.00'),
			('PRG4201','CONCURRENT & REAL-TIME SYSTEM','2000.00')";
			if(mysqli_query($link,$insertData2)){
				
			}
			else{
				echo mysqli_error($link);
			}
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table4="SELECT * FROM coursedetail";
	if(!mysqli_query($link,$table4)){

		$create4="CREATE TABLE coursedetail(
		courseid varchar(50) NOT NULL,
		FOREIGN KEY(courseid) REFERENCES course(courseid),
		section varchar(10) NOT NULL,
		lecturerid varchar(10) NOT NULL,
		FOREIGN KEY(lecturerid) REFERENCES lecturer(lecturerid),
		weekday int(1) NOT NULL,
		starttime time NOT NULL,
		classtime time NOT NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create4)){
			//insert data into coursedetail table
			$insertCdetailData =
			"INSERT INTO coursedetail VALUES
			('IBM4202','8G1','l1','2','15:00:00','02:00:00'),
			('IBM4202','8G1','l1','4','12:00:00','02:00:00'),
			('IBM4202','8G2','l1','3','14:00:00','02:00:00'),
			('IBM4202','8G2','l1','4','10:00:00','02:00:00'),
			('ITE4204','8G1','l2','1','10:00:00','02:00:00'),
			('ITE4204','8G1','l2','3','11:00:00','02:00:00'),
			('ITM4202','8G1','l3','3','13:00:00','01:00:00'),
			('ITM4202','8G1','l3','5','10:00:00','02:00:00'),
			('PRG3204','8G1','l4','1','16:00:00','02:00:00'),
			('PRG3204','8G1','l4','5','08:00:00','02:00:00'),
			('PRG4201','8G1','l5','2','12:00:00','02:00:00'),
			('PRG4201','8G1','l5','4','15:00:00','02:00:00'),
			('PRG4201','8G2','l5','2','08:00:00','02:00:00'),
			('PRG4201','8G2','l5','4','08:00:00','02:00:00')";
			if(mysqli_query($link,$insertCdetailData)){
			
			}
			else{
				echo mysqli_error($link);
			}
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table5="SELECT * FROM enrolledcourse";
	if(!mysqli_query($link,$table5)){

		$create5="CREATE TABLE enrolledcourse(
		studentid varchar(50) NOT NULL,
		FOREIGN KEY(studentid) REFERENCES student(studentid),
		courseid varchar(50) NOT NULL,
		FOREIGN KEY(courseid) REFERENCES course(courseid),
		section varchar(10) NOT NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create5)){
			
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	$table6="SELECT * FROM receipt";
	if(!mysqli_query($link,$table6)){

		$create6="CREATE TABLE receipt(
		id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		studentid varchar(50) NOT NULL,
		FOREIGN KEY(studentid) REFERENCES student(studentid),
		courseid varchar(50) NOT NULL,
		FOREIGN KEY(courseid) REFERENCES course(courseid),
		amount float(11) NOT NULL,
		paid float(11) NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create6)){
			
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	$table7="SELECT * FROM bank";
	if(!mysqli_query($link,$table7)){

		$create7="CREATE TABLE bank(
		id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		name varchar(50) NOT NULL,
		cardtype varchar(50) NOT NULL,
		cardnum varchar(50) NOT NULL UNIQUE KEY,
		month varchar(10) NOT NULL,
		year varchar(50) NOT NULL,
		cvv2 varchar(50) NOT NULL,
		country varchar(50) NOT NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create7)){
			
			$insertBank =
			"INSERT INTO bank VALUES
			('','Chin Jing Siang','Visa','7894561237894561','05','25','255','Malaysia'),
			('','Chin Jing Siang','Master','1234567891234567','05','25','255','Malaysia')";
			if(mysqli_query($link,$insertBank)){
				
			}
			else{
				echo mysqli_error($link);
			}
			
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	

	
	//select all item from this table
	$table8="SELECT * FROM attend";
	if(!mysqli_query($link,$table8)){

		$create8="CREATE TABLE attend(
		studentid varchar(50) NOT NULL,
		FOREIGN KEY(studentid) REFERENCES student(studentid),
		courseid varchar(50) NOT NULL,
		FOREIGN KEY(courseid) REFERENCES course(courseid),
		section varchar(10) NOT NULL,
		date date NOT NULL,
		present boolean NULL,
		absent boolean NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create8)){
			
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}

	$table9="SELECT * FROM qrcode";
	if(!mysqli_query($link,$table9)){

		$create9="CREATE TABLE qrcode(
		open boolean NULL,
		courseid varchar(50) NOT NULL,
		section varchar(10) NOT NULL,
		TodayDate date null
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create9)){
			//insert data into qrcode table
			$insertData9 = 
			"INSERT INTO qrcode VALUES
			('0', 'IBM4202', '8G1',''),
			('0', 'IBM4202', '8G2',''),
			('0', 'ITE4204', '8G1',''),
			('0', 'ITM4202', '8G1',''),
			('0', 'ITM4202', '8G3',''),
			('0', 'PRG3204', '8G1',''),
			('0', 'PRG4201', '8G1',''),
			('0', 'PRG4201', '8G2','')";

			if(mysqli_query($link,$insertData9)){
                    
               }
               else{
                    echo mysqli_error($link);
               }
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	//error message when fail to create database
	else{
		echo "Error creating database: " . mysqli_error($conn);
	}
	}
}
else{
	/* Attempt to connect to MySQL database */
	$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
	// Check connection
	if($link === false){
		die("ERROR: Could not connect. " . mysqli_connect_error());
	}
	
	//select all from table
	$table="SELECT * FROM student";
	//checking table if no then create
	if(!mysqli_query($link,$table)){

		$create1="CREATE TABLE student(
		id int(11) NOT NULL AUTO_INCREMENT UNIQUE KEY,
		studentid varchar(50) NOT NULL PRIMARY KEY,
		name varchar(50) NOT NULL,
		password varchar(255) NOT NULL,
		phone varchar(255) NOT NULL,
		address varchar(255) NOT NULL,
		international varchar(255) NOT NULL,
		email varchar(255) NOT NULL,
		enrollmentyear date NOT NULL,
		gender varchar(6) NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create1)){
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table2="SELECT * FROM lecturer";
	if(!mysqli_query($link,$table2)){

		$create2="CREATE TABLE lecturer(
		id int(11) NOT NULL AUTO_INCREMENT UNIQUE KEY,
		lecturerid varchar(10) NOT NULL PRIMARY KEY,
		name varchar(50) NOT NULL,
		password varchar(255) NOT NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create2)){

			//insert data into lecturer table
			$insertData =
			"INSERT INTO lecturer VALUES
			('','l1','David','lecture'),
			('','l2','John','lecture'),
			('','l3','Thomas','lecture'),
			('','l4','Sarasvathi','lecture'),
			('','l5','Bobby','lecture')";
			if(mysqli_query($link,$insertData)){
				
			}
			else{
				echo mysqli_error($link);
			}
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table3="SELECT * FROM course";
	if(!mysqli_query($link,$table3)){

		$create3="CREATE TABLE course(
		courseid varchar(50) NOT NULL PRIMARY KEY,
		coursename varchar(50) NOT NULL,
		courseprice float(11) NOT NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create3)){
						
			//insert data into course table
			$insertData2 =
			"INSERT INTO course VALUES
			('IBM4202','WEB PROGRAMMING WITH PHP','2000.00'),
			('ITE4204','COMPUTATIONAL MODELLING AND SIMULATION','2000.00'),
			('ITM4202','IT PROJECT MANAGEMENT','2000.00'),
			('PRG3204','WEB APPLICATION DEVELOPMENT','2000.00'),
			('PRG4201','CONCURRENT & REAL-TIME SYSTEM','2000.00')";
			if(mysqli_query($link,$insertData2)){
				
			}
			else{
				echo mysqli_error($link);
			}
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table4="SELECT * FROM coursedetail";
	if(!mysqli_query($link,$table4)){

		$create4="CREATE TABLE coursedetail(
		courseid varchar(50) NOT NULL,
		FOREIGN KEY(courseid) REFERENCES course(courseid),
		section varchar(10) NOT NULL,
		lecturerid varchar(10) NOT NULL,
		FOREIGN KEY(lecturerid) REFERENCES lecturer(lecturerid),
		weekday int(1) NOT NULL,
		starttime time NOT NULL,
		classtime time NOT NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create4)){
			//insert data into coursedetail table
			$insertCdetailData =
			"INSERT INTO coursedetail VALUES
			('IBM4202','8G1','l1','2','15:00:00','02:00:00'),
			('IBM4202','8G1','l1','4','12:00:00','02:00:00'),
			('IBM4202','8G2','l1','3','14:00:00','02:00:00'),
			('IBM4202','8G2','l1','4','10:00:00','02:00:00'),
			('ITE4204','8G1','l2','1','10:00:00','02:00:00'),
			('ITE4204','8G1','l2','3','11:00:00','02:00:00'),
			('ITM4202','8G1','l3','3','13:00:00','01:00:00'),
			('ITM4202','8G1','l3','5','10:00:00','02:00:00'),
			('PRG3204','8G1','l4','1','16:00:00','02:00:00'),
			('PRG3204','8G1','l4','5','08:00:00','02:00:00'),
			('PRG4201','8G1','l5','2','12:00:00','02:00:00'),
			('PRG4201','8G1','l5','4','15:00:00','02:00:00'),
			('PRG4201','8G2','l5','2','08:00:00','02:00:00'),
			('PRG4201','8G2','l5','4','08:00:00','02:00:00')";
			if(mysqli_query($link,$insertCdetailData)){
			
			}
			else{
				echo mysqli_error($link);
			}
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table5="SELECT * FROM enrolledcourse";
	if(!mysqli_query($link,$table5)){

		$create5="CREATE TABLE enrolledcourse(
		studentid varchar(50) NOT NULL,
		FOREIGN KEY(studentid) REFERENCES student(studentid),
		courseid varchar(50) NOT NULL,
		FOREIGN KEY(courseid) REFERENCES course(courseid),
		section varchar(10) NOT NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create5)){
			
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	$table6="SELECT * FROM receipt";
	if(!mysqli_query($link,$table6)){

		$create6="CREATE TABLE receipt(
		id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		studentid varchar(50) NOT NULL,
		FOREIGN KEY(studentid) REFERENCES student(studentid),
		courseid varchar(50) NOT NULL,
		FOREIGN KEY(courseid) REFERENCES course(courseid),
		amount float(11) NOT NULL,
		paid float(11) NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create6)){
			
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	$table7="SELECT * FROM bank";
	if(!mysqli_query($link,$table7)){

		$create7="CREATE TABLE bank(
		id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		name varchar(50) NOT NULL,
		cardtype varchar(50) NOT NULL,
		cardnum varchar(50) NOT NULL UNIQUE KEY,
		month varchar(10) NOT NULL,
		year varchar(50) NOT NULL,
		cvv2 varchar(50) NOT NULL,
		country varchar(50) NOT NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create7)){
			
			//insert data to the bank table
			$insertBank =
			"INSERT INTO bank VALUES
			('','Chin Jing Siang','Visa','7894561237894561','05','25','255','Malaysia'),
			('','Chin Jing Siang','Master','1234567891234567','05','25','255','Malaysia')";
			if(mysqli_query($link,$insertBank)){
				
			}
			else{
				echo mysqli_error($link);
			}
			
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	

	
	//select all item from this table
	$table8="SELECT * FROM attend";
	if(!mysqli_query($link,$table8)){

		$create8="CREATE TABLE attend(
		studentid varchar(50) NOT NULL,
		FOREIGN KEY(studentid) REFERENCES student(studentid),
		courseid varchar(50) NOT NULL,
		FOREIGN KEY(courseid) REFERENCES course(courseid),
		section varchar(10) NOT NULL,
		date date NOT NULL,
		present boolean NULL,
		absent boolean NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create8)){
			
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}

	//select all item from this table
	$table9="SELECT * FROM qrcode";
	if(!mysqli_query($link,$table9)){

		$create9="CREATE TABLE qrcode(
		open boolean NULL,
		courseid varchar(50) NOT NULL,
		section varchar(10) NOT NULL,
		TodayDate date null
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create9)){
			//insert data into qrcode table
			$insertData9 = 
			"INSERT INTO qrcode VALUES
			('0', 'IBM4202', '8G1',''),
			('0', 'IBM4202', '8G2',''),
			('0', 'ITE4204', '8G1',''),
			('0', 'ITM4202', '8G1',''),
			('0', 'ITM4202', '8G3',''),
			('0', 'PRG3204', '8G1',''),
			('0', 'PRG4201', '8G1',''),
			('0', 'PRG4201', '8G2','')";
			if(mysqli_query($link,$insertData9)){
                    
               }
               else{
                    echo mysqli_error($link);
               }
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}

}
?>
