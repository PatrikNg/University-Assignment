
<?php
session_start();
// Include config file
require_once "config.php";

$login_err = $login = $password = $password_err = $parem_password = $tid_err = $tid = null;

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST")
{
	
	// Check if tid is empty
	if(empty($_POST["tid"]))
	{
		$tid_err = "Please enter lecturer ID.";
	} 
	else
	{
		$tid = $_POST["tid"];	
	}
		
	// Check if password is empty
	if(empty($_POST["password"]))
	{
		$password_err = "Please enter your password.";
	} 
	else
	{
		$password = $_POST["password"];
	}

	// Validate credentials
    if(empty($tid_err) && empty($password_err))
   	{
        // Prepare a select statement
    	$link=mysqli_connect('localhost','root','');
  		mysqli_select_db($link, 'attendsystem');
  		$sql = mysqli_query($link, "SELECT lecturerid FROM lecturer WHERE lecturerid LIKE '$tid'");
      	$name = mysqli_fetch_row($sql);
      	$sql1 = mysqli_query($link, "SELECT name FROM lecturer WHERE lecturerid LIKE '$tid'");
      	$uname = mysqli_fetch_row($sql1);

      	$uid = $name[0];

      	//check if the name store in data and the enter data is same or not
       	if($uid == $tid )
      	{
                          
            $query = mysqli_query($link,"SELECT password FROM lecturer WHERE lecturerid='$tid'")or die( mysqli_error($link));
    		$pass = mysqli_fetch_row($query);
    		$parem_password = $pass[0];

            if($password == $parem_password)
            {
              	// Password is correct, so start a new session
                                
               	// Store data in session variables
               	$_SESSION["loggedin"] = true;
               	$_SESSION["id"] = $tid;
               	$_SESSION['tname'] = $uname[0];
               
               	// Redirect user to profile page
               	header("location: attend.php");
           	} 
           	else
         	{
               	// Password is not valid, display a generic error message
              	$login_err = "Invalid ID or password.";
         	}
       	} 
      	else
      	{
           	// tid doesn't exist, display a generic error message
           	$login_err = "Invalid ID or password.";
     	}
  	}
  	else
   	{
   		//check the password and id has enter or not
      	if(!empty($tid_err) || !empty($password_err))
      	{
			$login_err = "Please enter your ID and password.";
		}
		else
		{
			echo "Oops! Something went wrong. Please try again later.";
		}
     }
}

    // Close connection
	mysqli_close($link);

?>
	 
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Lecture Login</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<style>
			body{ font: 14px sans-serif; background-image:url(images/login_back.jpg);}
			.wrapper{ width: 360px; padding: 20px; }
		</style>
	</head>
	<body>
		<div class="wrapper">
		<?php 
			if(!empty($login_err)){
				echo '<div class="alert alert-danger">' . $login_err . '</div>';
			}
		?>
			<h2>Lecture login</h2>
			<p>Please fill in your credentials to login.</p>
			
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" >
				<div>
					<a class="btn btn-warning" href="login.php">Student login</a>.
					<a class="btn btn-warning" href="admin.php">Teacher Login</a>.
				</div><br />
				<div class="form-group">
					<label>lecturer ID</label>
					<input type="text" name="tid" class="form-control <?php echo (!empty($tid_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $tid; ?>">
					<span class="invalid-feedback"><?php echo $tid_err; ?></span>
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?> " value="<?php echo $password; ?>">
					<span class="invalid-feedback"><?php echo $password_err; ?></span><br />
				<div class="form-group">
					<input type="submit" class="btn btn-warning" value="Login">
				</div>
			</form>	
		</div>
	</body>
	</html>