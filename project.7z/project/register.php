<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = $userid = $usid = $username_err = $phone = $phone_err = $password_err = $confirm_password_err = $confirm_password_err = $email = $email_err = $confirm_password_err = $gender_err = $nation = $nation_err = $year = $year_err = ""; 

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    // Validate username
    if(empty($_POST["username"]))
    {
        $username_err = "Please enter a username.";
    } 
    else
    {
        // Prepare a select statement
        $sql = "SELECT id FROM students WHERE name = ?";
        $sqlname = mysqli_query($link,"SELECT name FROM student")or die( mysqli_error($link));
        $uname = mysqli_fetch_row($sqlname);
            
        if($stmt = mysqli_prepare($link, $sql))
        {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $username);
                
            // Set parameters
            $param_username = trim($_POST["username"]);
                
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt))
            {
                /* store result */
                mysqli_stmt_store_result($stmt);
                    
                if(mysqli_stmt_num_rows($stmt) == 1)
                {
                    $username_err = "This username is already taken.";
                } 
                else
                {
                    $username = trim($_POST["username"]);
                }
            }
            else
            {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    //validate the email
    if(empty($_POST["email"]))
    {
        $email_err = "Please enter email.";     
    } 
    else
    {
        $email = $_POST["email"];
    }

    //validate the gender
    if(empty($_POST["gender"]))
    {
        $gender_err = "Please enter your gender.";     
    } 
    else
    {
        $gender = $_POST["gender"];
    }
        
    // Validate password
    if(empty(trim($_POST["password"])))
    {
        $password_err = "Please enter a password.";     
    } 
    elseif(strlen($_POST["password"]) < 6)
    {
        $password_err = "Password must have atleast 6 characters.";
    } 
    else
    {
        $password = $_POST["password"];
    }
        
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"])))
    {
        $confirm_password_err = "Please confirm password.";     
    } 
    else
    {
        $confirm_password = $_POST["confirm_password"];
        if(empty($password_err) && ($password != $confirm_password))
        {
            $confirm_password_err = "Password did not match.";
        }
    }

    // Validate phone
    if(empty($_POST["phone"]))
    {
        $phone_err = "Please enter a phone number.";     
    } 
    elseif(strlen($_POST["phone"]) < 10)
    {
        $phone_err = "Password must have atleast 10 digits .";
    } 
    else
    {
        $phone = $_POST["phone"];
    }

    //validate the address
    if(empty($_POST["address"]))
    {
        $address_err = "Please enter your Address.";     
    } 
    else
    {
        $address = $_POST["address"];
    }

    //validate the nation
    if(empty($_POST["nation"]))
    {
        $nation_err = "Please enter your nation.";     
    } 
    else
    {
        $nation = $_POST["nation"];
    }

    //validate the year
    if(empty($_POST["year"]))
    {
        $year_err = "Please enter enrollment year.";     
    } 
    else
    {
        $year = $_POST["year"];
    }

    if(!empty($_POST['username']) && !empty($_POST['password']) )
    {
        //link to database
        $link=mysqli_connect('localhost','root','');
        mysqli_select_db($link, 'attendsystem');

        //select the data from database
        $id = mysqli_query($link,"SELECT MAX(id) FROM student")or die( mysqli_error($link));
        $sid = mysqli_fetch_row($id);

        //set the userid
        if($sid[0] == null)
        {
            $ud = ("I1");
        }
        else
        {
            foreach ($sid as $key) 
            {
                $key = $key + 1;
            }   
            $ud = ("I$key");
        }
                
        //save data in database
        $us = mysqli_real_escape_string($link, $_POST['username']);
		//password encryption
		$pwd = password_hash($_POST['password'], PASSWORD_DEFAULT); // Creates a password hash
        $p = mysqli_real_escape_string($link, $_POST['phone']);
        $add = mysqli_real_escape_string($link, $_POST['address']);
        $na = mysqli_real_escape_string($link, $_POST['nation']);
        $em = mysqli_real_escape_string($link, $_POST['email']);
        $ye = mysqli_real_escape_string($link, $_POST['year']);
        $ge = mysqli_real_escape_string($link, $_POST['gender']);
            
        $insert = mysqli_query($link, "INSERT INTO student (studentid, name, password, phone, address, international, email, enrollmentyear, gender) VALUES ('$ud', '$us', '$pwd', '$p', '$add', '$na', '$em', '$ye', '$ge')");

        if($insert)
        {
            $successMessage = "Success register the account. <br />Student ID = $ud";
        } 
        else 
        {
            echo 'Failed to add new record because '.mysqli_error($link);
        }

        mysqli_close($link);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; 
            background-image:url(images/login_back.jpg);
            background-attachment: fixed;}
        .wrapper{ width: 360px; 
                padding: 20px; }
        .error {color: #FF0000;}
        .column {width: 100%;
                height: 150%;}
    </style>
</head>
<body>
    <div class="wrapper">
    <?php 
        if(!empty($successMessage))
        {
            echo '<div class="alert alert-success">' . $successMessage . '</div>';          
        }        
        ?>
        <h2>Sign Up</h2>
        <p>Please fill this form to create an account.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="username" class="form-linktrol <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" >
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-linktrol <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" >
                <span class="invalid-feedback"><?php echo $email_err; ?></span>
            </div>
            <div class="form-group">
                Gender:</br>
                <input type="radio" name="gender"
                <?php if (isset($gender) && $gender=="female") echo "checked";?>
                value="female">Female
                <input type="radio" name="gender"
                <?php if (isset($gender) && $gender=="male") echo "checked";?>
                value="male">Male
                <span class="error">* <?php echo $gender_err;?></span><br />
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-linktrol <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" >
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-linktrol <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="form-group">
                <label>Phone Number</label>
                <input type="tel" name="phone" class="form-linktrol <?php echo (!empty($phone_err)) ? 'is-invalid' : ''; ?>" >
                <span class="invalid-feedback"><?php echo $phone_err; ?></span>
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="tel" name="address" class="form-linktrol <?php echo (!empty($address_err)) ? 'is-invalid' : ''; ?>" >
                <span class="invalid-feedback"><?php echo $address_err; ?></span>
            </div>
            <div class="form-group">
                Nation:</br>
                <input type="radio" name="nation"
                <?php if (isset($nation) && $nation=="local") echo "checked";?>
                value="local">Local
                <input type="radio" name="nation"
                <?php if (isset($nation) && $nation=="international") echo "checked";?>
                value="international">International
                <span class="error">* <?php echo $nation_err;?></span>
            </div>
            <div class="form-group">
                <label>Enrollment Year</label>;
                <input type="date" name="year" max="<?php $today = date('Y-m-d'); echo $today; ?>" value="<?php $today = date('Y-m-d'); echo $today; ?>" class="form-linktrol <?php echo (!empty($year_err)) ? 'is-invalid' : ''; ?>" >
                <span class="invalid-feedback"><?php echo $year_err; ?></span>
            </div>          
            <div class="form-group">
                <input type="submit" class="btn btn-warning" value="Sign Up">
                <input type="reset" class="btn btn-danger ml-2" value="Reset">
            </div>
            <p>Already have an account? <a href="login.php">Login</a>.</p>
        </form>
    </div>    
</body>
</html> 