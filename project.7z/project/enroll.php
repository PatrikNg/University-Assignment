<?php
// Include config file
require "design.php";
include("config.php");

$sid = $_SESSION["sid"];



			   
			if(isset($_POST['course_id'])){
			echo '<option value="">Select Section</option>';
			$sectionGet = mysqli_query($link,"SELECT DISTINCT(section) from coursedetail where courseid='$_POST[course_id]' ") or die(mysqli_error($link));
			$sectionData = mysqli_fetch_row($sectionGet);
				if(!empty($sectionData)){
					do{
						//$sectionArr +=array($sectionData[0]);
?>
						<option value="<?php echo $sectionData[0];?>"><?php echo $sectionData[0];?></option>
<?php
					$sectionData = mysqli_fetch_row($sectionGet);
					}while($sectionData);
					
				}
				
			}



// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST")
{
         //save data in database
        $courseid = mysqli_real_escape_string($link, $_POST['courseid']);
        $section = mysqli_real_escape_string($link, $_POST['section']);
		
		$Check = mysqli_query($link,"SELECT * FROM enrolledcourse where studentid='$sid' and courseid='$courseid' ")or die(mysqli_error($link));
		$GetCheck = mysqli_fetch_row($Check);
		
		if(empty($GetCheck)){
			$insert = mysqli_query($link,"INSERT INTO enrolledcourse (studentid, courseid, section) VALUES ('$sid', '$courseid', '$section')");

			if($insert)
			{
				$money=mysqli_query($link,"SELECT courseprice from course where courseid='$courseid' ");
				$moneyGet=mysqli_fetch_row($money);
				
				$receipt=mysqli_query($link,"INSERT INTO receipt (studentid,courseid,amount,paid) values ('$_SESSION[sid]','$courseid','$moneyGet[0]','0')") or die(mysqli_error($link));
				$successMessage = "Enrolled Successfully";
			} 
			else 
			{
				echo 'Failed  '.mysqli_error($link);
			}
		}
		else{
			$errorMsg="You already enrolled this course, cannot take again!";
		}

    }

?>

<script type="text/javascript">
function FetchSection(cid){
	
	$('#section').html('');
    $.ajax({
      type:'post',
      url: 'enroll.php',
      data : { course_id : cid},
      success : function(data){
         $('#section').html(data);
      }

    })
	//alert(cid);
}

</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enrollment</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <style>
        body{ font: 14px sans-serif; 
            background-image:url(images/login_back.jpg);
            background-attachment: fixed;}
        .wrapper{ width: 400px; 
                padding: 20px;
				margin-top:50px;
				margin-left:500px;}
        .error {color: #FF0000;}
        .column {width: 100%;
                height: 150%;}
    </style>
</head>
<body>
    <div class="wrapper">

        <h2>Enrollment</h2>

        <form action="enroll.php" method="post">
                <div class="form-group">
                <label>Studnt ID</label>
                <input type="text" class="form-control" id="studentid" name="studentid" value="<?php echo $sid?>" disabled>
  
            
				</div>

            <div class="form-group">
			<label for="Course">Course</label>
			<select class="form-control" name="courseid" id="courseid" onchange="FetchSection(this.value)" required>
			<option value="">Select Course</option>   
			<?php 
			$sql=mysqli_query($link,"select * from course");
			while($row=mysqli_fetch_array($sql))
			{
			?>
			<option value="<?php echo htmlentities($row['courseid']);?>"><?php echo htmlentities($row['courseid']);?></option>
			<?php } ?>

			</select> 
			</div>
			
			
			
        
        
			<div class="form-group">
			<label for="Section">Section  </label>
			<select class="form-control" name="section" id="section" required>
			<option value="">Select Section</option>   

			</select> 
			</div>
               

          
            
            <div class="form-group">
                <input type="submit" class="btn btn-warning" value="Enroll">
                 <a href="profile.php" class="btn btn-warning ml-3">Cancel</a>
            </div>
          
        </form>
	<?php 
        if(!empty($successMessage))
        {
            echo '<div class="alert alert-success">' . $successMessage . '</div>';          
        }       

		if(!empty($errorMsg)){
            echo '<div class="alert alert-danger">' . $errorMsg . '</div>';
        }       
    ?>
    </div>    
	
</body>
</html> 


