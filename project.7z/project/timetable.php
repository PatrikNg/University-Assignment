<?php
require "design.php";
include("config.php");

$sid = $_SESSION["sid"];

	//retrieve data from coursedetail table based on current student and his enrolled course section
	$getDate = mysqli_query($link,"Select * from coursedetail join enrolledcourse on 
	enrolledcourse.courseid = coursedetail.courseid where enrolledcourse.studentid='$sid' and coursedetail.section=enrolledcourse.section ") or die(mysqli_error($link));
	$getted = mysqli_fetch_array($getDate);
	//array declaration
	//for monday
	$wd1 =array();
	//for tuesday
	$wd2 =array();
	//for wednesday
	$wd3 =array();
	//for Thursday
	$wd4 =array();
	//for Friday
	$wd5 =array();
	//if having data 
	if(!empty($getted)){
		do{
			//store the course id and section into $cNsection
			$cNsection = "$getted[0] $getted[1]";
			//if weekday of the course is 1 then will store into array $wd1
			if($getted[3]==1){
				//store the start time of the course as key and course id and section as value
				$wd1 +=array($getted[4]=>$cNsection);
				//Add start time with the length of the class time for getting the end time of this course and store the end time of the course as key and course id and section as value
				$wd1 +=array(date("H:i:s",strtotime($getted[4])+strtotime($getted[5]))=>$cNsection);
			}
			//if weekday of the course is 2 then will store into array $wd2
			else if($getted[3]==2){
				$wd2 +=array($getted[4]=>$cNsection);
				$wd2 +=array(date("H:i:s",strtotime($getted[4])+strtotime($getted[5]))=>$cNsection);
			}
			else if($getted[3]==3){
				$wd3 +=array($getted[4]=>$cNsection);
				$wd3 +=array(date("H:i:s",strtotime($getted[4])+strtotime($getted[5]))=>$cNsection);
			}
			else if($getted[3]==4){
				$wd4 +=array($getted[4]=>$cNsection);
				$wd4 +=array(date("H:i:s",strtotime($getted[4])+strtotime($getted[5]))=>$cNsection);
			}
			else if($getted[3]==5){
				$wd5 +=array($getted[4]=>$cNsection);
				$wd5 +=array(date("H:i:s",strtotime($getted[4])+strtotime($getted[5]))=>$cNsection);
			}
					
			
			$getted = mysqli_fetch_array($getDate);

		}while($getted);
	}

	
	
?>




 
<!DOCTYPE html>
<html lang="en">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<head>
    <meta charset="UTF-8">
    <title>Time Table</title>
</head>
<body>
<br/>
	<form action="timetable.php" method="POST">
	
<?php
//getting course id, coursename,lecturer name and section from different table based on the course and section that student enrolled
$getCData = mysqli_query($link,"Select distinct coursedetail.courseid, course.coursename,
 lecturer.name,coursedetail.section from coursedetail join enrolledcourse on enrolledcourse.courseid = coursedetail.courseid
 join lecturer on lecturer.lecturerid=coursedetail.lecturerid join course on course.courseid=coursedetail.courseid
 where enrolledcourse.studentid='$sid' and coursedetail.section=enrolledcourse.section ") or die(mysqli_error($link));
 //fetching data
	$CDataGtted = mysqli_fetch_row($getCData);
	//if having data then print it as a table
	if(!empty($CDataGtted)){
		echo "<div style='margin-left:21%; display:flex;'><table>";
		echo "<th>No</th><th>Course ID</th><th>Course Name</th><th>Lecturer</th><th>Section</th>";
		$i=1;
		do{
			echo "<tr>";
			echo "<td style='padding-right:25px;'>$i</td>";
			echo "<td style='padding-right:25px;'>$CDataGtted[0]</td>";
			echo "<td style='padding-right:20px;'>$CDataGtted[1]</td>";
			echo "<td style='padding-right:40px;'>$CDataGtted[2]</td>";
			echo "<td>$CDataGtted[3]</td>";
			$i++;
			echo "</tr>";
			$CDataGtted = mysqli_fetch_row($getCData);
		}while($CDataGtted);
		echo "</table></div>";
	}

?>
<br/>
<div style="justify-content:center; display:flex;">



<table border="2px solid" style="border-color:black;" width=910px; >
<tr style="background-color:white;">
<td></td>
<?php
//set the timetable start from 8 am and end at 20pm, if the time not bigger than 20pm then will keep looping
	$begin=date("08:00");
	while($begin<=date("20:00")){
		echo "<td style='width:70px;'>$begin</td>";
		//adding time to the $begin so will make it from 8am to 9am and so on
		$begin =date("H:i",strtotime($begin)+strtotime(date("02:00")));
	}
?>
</tr>

<tr style="background-color:#FF0000;color:white;">
<td style="width:30px;">MON</td>
<?php
//set the timetable start from 8 am and end at 20pm, if the time not bigger than 20pm then will keep looping
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		//if the time that is stored as key was matched
		if(array_key_exists($begin,$wd1)){
			//use for each to find the course of current time and print it out
			foreach($wd1 as $Ctime=>$Cdetail){
				if($Ctime==$begin){
					echo "<td>$Cdetail</td>";
					break;
				}
			}
		}
		else{
			echo "<td></td>";
		}
		//adding time to the $begin so will make it from 8am to 9am and so on
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>

<tr style="background-color:#FF7F00;color:white;">
<td>TUE</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		if(array_key_exists($begin,$wd2)){
			foreach($wd2 as $Ctime=>$Cdetail){
				if($Ctime==$begin){
					echo "<td>$Cdetail</td>";
					break;
				}
			}
		}
		else{
			echo "<td></td>";
		}
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
	
?>
</tr>



<tr style="background-color:#FFFF00;color:black;">
<td>WED</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		if(array_key_exists($begin,$wd3)){
			foreach($wd3 as $Ctime=>$Cdetail){
				if($Ctime==$begin){
					echo "<td>$Cdetail</td>";
					break;
				}
			}
		}
		else{
			echo "<td></td>";
		}
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>


<tr style="background-color:#00FF00;color:black;">
<td>THU</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		if(array_key_exists($begin,$wd4)){
			foreach($wd4 as $Ctime=>$Cdetail){
				if($Ctime==$begin){
					echo "<td>$Cdetail</td>";
					break;
				}
			}
		}
		else{
			echo "<td></td>";
		}
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>



<tr style="background-color:#0000FF;color:white;">
<td>FRI</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		if(array_key_exists($begin,$wd5)){
			foreach($wd5 as $Ctime=>$Cdetail){
				if($Ctime==$begin){
					echo "<td>$Cdetail</td>";
					break;
				}
			}
		}
		else{
			echo "<td></td>";
		}
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>

<tr style="background-color:#4B0082;color:white;">
<td>SAT</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		echo "<td></td>";
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>

<tr style="background-color:#9400D3;color:white;">
<td>SUN</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		echo "<td></td>";
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>

</table>
</div>
<br/>
</body>
</html>