<?php
include("config.php");

if(isset($_POST['back']))
{
	header("location: login.php");
}

if(isset($_POST['submit']))
{
	//get the entered data from student
	$uid = $_POST['uid'];
	$phoneNo = $_POST['phoneNo'];
	//select matched data from database
	$query = mysqli_query($link,"SELECT * FROM student where studentid='$uid' and phone='$phoneNo' ")or die( mysqli_error($link));
	$Row = mysqli_fetch_row($query);
	
	if($uid!=null && $phoneNo!=null)
	{
		//if nothing being selected then will tell the student he is failed to reset password
		if($Row !=null){
			//create two array one is 'a' to 'e' another is 1 to 6 then merge it to a single array
			$randomCreate = array_merge(range("a","e"),range(1,6));
			//randomly rearrange the array
			shuffle($randomCreate);
			//made the array to a string
			$newPassw = implode($randomCreate);
			//password will be encrypted and store in to database
			$hashedPwdInDb = password_hash($newPassw,PASSWORD_DEFAULT);
			
			$update = mysqli_query($link, "UPDATE student SET password='$hashedPwdInDb' where studentid='$uid' and phone='$phoneNo'");
			if($update)
			{
				header("Location:resetted.php?newPwd=$newPassw");
			} 
			else 
			{
				echo 'Failed to reset password because '.mysqli_error();
			}
		}
		else
		{
			$erroMessage = "Your are failed to reset password because of wrong uid or Phone Number Entered.";
		}
	}
	else
	{
		$erroMessage = "You need to enter your uid and password!";
	}

	mysqli_close($link);

}
?>

<!DOCTYPE html>
<html>
<title>Reset Password</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
		
        body{ 
		font: 14px sans-serif; 
		background-image:url(images/login_back.jpg);
		}
				
        #content{ 
		width: 360px;
		padding: 20px; 
		}
		
		#required{
			font-size:20px;
		}
		
    </style>
	
<body>

<div id="content">

		<?php 
        if(!empty($erroMessage)){
            echo '<div class="alert alert-danger">' . $erroMessage . '</div>';
        }        
        ?>
		
<form method="post" action="resetPwd.php">
<h2>Reset</h2>
<p>Please enter your uid and your phone number.</p>
<label id="required";>Studen ID</label><br />
<input type="text" name="uid" class="form-control" /><br/>
<label id="required";>Phone Number</label><br />
<input type="text" name="phoneNo" class="form-control" /><br />
<input type="submit" name="submit" value="Submit" class="btn btn-warning" /> &nbsp
<input type="submit" name="back" value="Back" class="btn btn-warning" />

</div>

</form>

</body>
</html>