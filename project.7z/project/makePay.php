<?php
require "design.php";
include("config.php");

$sid = $_SESSION["sid"];
 

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;

}
	if(isset($_POST['paid'])){
		
		
		$bankData = mysqli_query($link,"SELECT * FROM bank where cardtype='$_POST[cardType]' 
		and cardnum='$_POST[cardNum]' and month='$_POST[month]' and year='$_POST[year]' and cvv2='$_POST[cvv2]' ")or die(mysqli_error($link));
		$bankGet = mysqli_fetch_row($bankData);
		if(!empty($bankGet)){
			$pay =mysqli_query($link,"UPDATE receipt set paid=amount where studentid='$sid' and amount>paid ");
			$successMsg="Tuition fee is paid successfully";
		}
		else{
			$erroMessage="Payment Fail. You may type the wrong detail.";
		}

	}

	
	

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .Pro{text-align: center; font-size: 20px;}
        .ab{ text-align: center;font-size: 25px;}
        .word{text-align: center; font-size: 20px;margin-left: auto;margin-right: auto;}
  
    </style>
</head>
<body>
	<form action="makePay.php" method="POST">

	<?php
	if(empty($successMsg)){
	?>
    <div>
	<br/>
        <table class="word" border=1 style="background-color:black;color:white">
            <tr>
                <td colspan="2" class="ab" width="390px" style="color:red">Please enter your card details</td>
            </tr>
			<tr>
                <td style="text-align:left;padding:2px;">Name on Card:</td>
                <td class="Pro" style="text-align:left;">
					<input type="text" name="name" required>

                </td>
            </tr>
			 <tr>
                <td style="text-align:left;padding:2px;">Card Type:</td>
                <td class="Pro" style="text-align:left;">
				<input type="radio" name="cardType" value="visa" required>
				<label>Visa</label>
				<input type="radio" name="cardType" value="master">
				<label>Master</label>
                </td>
            </tr>
			
			<tr>
                <td style="text-align:left;padding:2px;">Card Number:</td>
                <td class="Pro" style="text-align:left;">
				<input type="text" name="cardNum" required>

                </td>
            </tr>
			<tr>
			<td style="text-align:left;padding:2px;">Expiry Date:</td>
			<td class="Pro" style="text-align:left;">
			<input style="width:45px;" type="text" name="month" placeholder="MM" pattern="[0-9]{2}" required> /
			<input style="width:45px;" type="text" name="year" placeholder="YY" pattern="[0-9]{2}" required> 
			</td>
			</tr>
			
			<tr>
			<td style="text-align:left;padding:2px;">Card CVV2/CVC2: </td>
				<td class="Pro" style="text-align:left;">
				<input type="text" name="cvv2" required> 
				</td>
			</tr>

			<tr>
				<td colspan="2">
					<input class="btn btn-warning" type="submit" name="paid" value="Paid">
					<a href="paymentshow.php" class="btn btn-warning ml-3">Cancel</a>
				</td>
			</tr>
        </table>
		<br/>
    </div>
	<?php
	}
	else{
	?>
	<div style="justify-content:center; display:flex;" width="50px">
	<?php
		echo "<br/>";
		echo '<div class="alert alert-success">' . $successMsg . '</div>';
		echo "<br/>";
	
	?>
	
	</div>
	
	<div style="justify-content:center; display:flex;">
	<a href="profile.php" class="btn btn-warning ml-3" >Back</a>
	</div>
	<?php
	}
	?>
	
		<div style="justify-content:center; display:flex;" width="50px">
	
	<?php
		if(!empty($erroMessage)){
			echo '<div class="alert alert-danger">' . $erroMessage . '</div>';
		}
	?>
	</div>
	</form>
</body>
</html>