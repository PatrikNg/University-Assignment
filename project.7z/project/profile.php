<?php
require "design.php";
include("config.php");

$sid = $_SESSION["sid"];

$link=mysqli_connect('localhost','root','');
 mysqli_select_db($link, 'attendsystem');

$query = mysqli_query($link,"SELECT * FROM student where studentid='$sid' ")or die( mysqli_error($link));
$row = mysqli_fetch_row($query);
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;

}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .Pro{text-align: center; font-size: 20px;}
        .ab{ text-align: center;font-size: 25px;}
        .word{text-align: center; font-size: 20px;margin-left: auto;margin-right: auto; font-family: Bookman, URW Bookman L, serif;}
  
    </style>
</head>
<body>
    <div style="margin: 10px;">
        <table border="2" class="word" width="480px" style="border: 1;">
            <tr>
                <td colspan="2" class="table-active">Profile</td>
            </tr>
            <tr class="table-primary">
                <td style="text-align:left;padding:2px;" >Student ID:</td>
                <td style="text-align:left;padding:2px;">
                    <?php echo $row[1];?>
                </td>
            </tr>
            <tr class="table-secondary">
                <td style="text-align:left;padding:2px;" >Student Name:</td>
                <td class="Pro" style="text-align:left;padding:2px;">
                    <?php echo $row[2]; ?>
                </td>
            </tr>
            <tr class="table-success">
                <td style="text-align:left;padding:2px;">Phone number:</td>
                <td style="text-align:left;padding:2px;">
                    <?php echo $row[4];?>
                </td>
            </tr>
            <tr class="table-info">
                <td style="text-align:left;padding:2px;">Address:</td>
                <td style="text-align:left;padding:2px;">
                    <?php echo $row[5];?>
                </td>
            </tr>
            <tr class="table-primary">
                <td style="text-align:left;padding:2px;" >Nationality:</td>
                <td style="text-align:left;padding:2px;">
                    <?php echo $row[6];?>
                </td>
            </tr>
                <tr class="table-secondary">
                <td style="text-align:left;padding:2px;">Email:</td>
                <td style="text-align:left;padding:3px;">
                    <?php echo $row[7];?>
                </td>
            <tr class="table-success">
                <td style="text-align:left;padding:2px">Enrollment Year:</td>
                <td style="text-align:left;padding:2px">
                    <?php echo $row[8];?>
                </td>
            </tr>
            <tr class="table-info">
                <td style="text-align:left;padding:2px">Gender:</td>
                <td style="text-align:left;padding:2px">
                    <?php echo $row[9];?>
                </td>
            </tr>
            <tr>
                <td class="table-danger">
                    <a href="changePwd.php">Change Password</a>
                </td>
                <td class="table-danger">
                    <a href="editProfile.php">Edit Profile</a>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>