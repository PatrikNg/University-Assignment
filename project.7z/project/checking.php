<?php

	//include required phpmailer files
	require 'email\src\Exception.php';
	require 'email\src\PHPMailer.php';
	require 'email\src\SMTP.php';
					
	//define name spaces
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;

	$lID = $_SESSION["id"];;
	$cID = $_POST['courseid'];;
	$section = $_POST['section'];
	
	//get the weekday from coursedetail based on specific course id, section and lecturer
	$getWDay = mysqli_query($link,"SELECT weekday FROM coursedetail where lecturerid='$lID' and courseid='$cID' and section='$section' ");
	$wday = mysqli_fetch_row($getWDay) or die (mysqli_error($link));
	//variable declaration and initial
	$total=0;
	//if data found
	if(!empty($wday)){

		do
		{	
		//call the function and store the return value into $total
		$total += calTotal($wday[0]);
		$wday = mysqli_fetch_row($getWDay);
		}while($wday);	
		
	}
	//array declaration
	$Warning =array();
	
	//update the student attend status, if the student does not attend the class then will make the absent column to be 1 or else the value of absent column should be null
	$updating = mysqli_query($link,"update attend set absent='1' where courseid='$cID' and section='$section' and present is null ")or die(mysqli_error($link));
	//select all the student that enrolled into this course and this section
	$getStudent = mysqli_query($link,"SELECT distinct studentid from attend where courseid='$cID' and section='$section'")or die(mysqli_error($link));
	$studentid = mysqli_fetch_row($getStudent);
	//if having student enrolled into this course
	if(!empty($studentid)){
		//if having data then kept looping
		do{
			//count the total absent of each student that enrolled this course
			$check = mysqli_query($link,"SELECT count(absent) from attend where courseid='$cID' and section='$section' and studentid='$studentid[0]' ")or die(mysqli_error($link));
			$checkResult = mysqli_fetch_row($check);
			$cal = $checkResult[0];
			//if absent rate more than 20%
			if(($cal/$total*100)>20){
				//getting the name and email of this student
				$emailGet = mysqli_query($link,"SELECT name,email from student where studentid='$studentid[0]'")or die(mysqli_error($link));
				$emailData = mysqli_fetch_row($emailGet);
				//store the data into the array and set email as key, name as value
				$Warning +=array($emailData[1]=>$emailData[0]);
			}
			
			
			$studentid = mysqli_fetch_row($getStudent);
		}while($studentid);
		
	}
	
	//for getting total of the specific weekday in this month
	function calTotal($weekDay){
		//set the start date equal to first date of current year and month
		$startDate = strtotime(date("y-m-01"));
		//set the end date is the last date in currnt month
		$endDate = strtotime(date("y-m-t"));

		
		$totalDate=0;
		//while startDate not yet bigger than end date
		while($startDate<=$endDate){
		//getting weekday in integer data type
		$what=date("N",$startDate);
		//if today is the weekday we specified
			if($what==$weekDay){
				//add by 1
				$totalDate++;
			}
			//add one day (24h*60m*60s)
			$startDate +=86400;
		}
		//return value
		return $totalDate;
	}
	
	
	if(!empty($Warning)){
		foreach ($Warning as $k=>$v){
			
			//create instance of phpmailer
			$mail = new PHPMailer();
							
			//set mailer to user smtp
			$mail -> isSMTP();
							
			//define smtp host
			$mail -> Host = 'smtp.gmail.com';
							
			//enable smtp authentication
			$mail -> SMTPAuth = TRUE;
							
			//set type of encryption (ssl/tls)
			$mail -> SMTPSecure = "tls";
							
			//set port to connect smtp
			$mail -> Port = 587;
							
			//set gmail username
			$mail -> Username = "phpMyAssignment@gmail.com";
							
			//set gmail password
			$mail -> Password = "php_1234";
							
			//set emai subject
			$mail -> Subject = "Warning Letter From Course $cID $section";
							
			//set sender email
			$mail -> setfrom("phpMyAssignment@gmail.com");
							
			//enable HTML format in email
			$mail-> isHTML(true);
							
			//email body
			$mail ->Body = "$v your attendance in this month is less than 80%.";
							
							
			//add recipient
			$mail -> addAddress("$k");
							
			//finally send email
			if($mail -> Send())
			{
			}
			else
			{
				echo "Error ..!". $mail->ErrorInfo;
			}
			$mail -> smtpClose();	
		}
	}
	else{
		
	}
?>