<?php
session_start();

if(empty($_SESSION['chk']))
{
	$_SESSION['chk']=0;
}

// Include config file
require_once "config.php";

//if the cookie not store anything, it will set the student id and password as null
if(empty($_COOKIE['cid']))
{
	// Define variables and initialize with empty values
	$sid = $password = "";
	$sid_err = $password_err = $login_err = "";
}
else
{//if the cookie has store the variable, the sid and password will become cookie store things.
	$sid = $_COOKIE['cid'];
	$password = $_COOKIE['cpswd'];

}

//check session chk check if the user want to use cookie to automatic login or not
if($_SESSION['chk']==1)
{
	header("location: profile.php");
}
else
{

	// Processing form data when form is submitted
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
	
		// Check if sid is empty
		if(empty($_POST["sid"]))
		{
			$sid_err = "Please enter Student ID.";
		} else
		{
			$sid = $_POST["sid"];	
		}
		
		// Check if password is empty
		if(empty($_POST["password"]))
		{
			$password_err = "Please enter your password.";
		} else
		{
			$password = $_POST["password"];
		}

		// Validate credentials
        if(empty($sid_err) && empty($password_err))
        {
            // Prepare a select statement
            $link=mysqli_connect('localhost','root','');
            mysqli_select_db($link, 'attendsystem');
            $sql = mysqli_query($link, "SELECT studentid FROM student WHERE studentid LIKE '$sid'");
            $name = mysqli_fetch_row($sql);
            $sql1 = mysqli_query($link, "SELECT name FROM student WHERE studentid LIKE '$sid'");
            $uname = mysqli_fetch_row($sql1);

            if(!empty($name))
            {
            	$uid = $name[0];
            }
            else
            {
            	$uid = null;
            }
            
		    if($uid == $sid )
            {
                          
            $query = mysqli_query($link,"SELECT password FROM student WHERE studentid='$sid'")or die( mysqli_error($link));
    			$pass = mysqli_fetch_row($query);
    			$parem_password = $pass[0];

                if(password_verify($password,$parem_password))
                {
                   	// Password is correct, so start a new session
                                
                  	// Store data in session variables
                   	$_SESSION["loggedin"] = true;
                   	$_SESSION["id"] = $id;
                   	$_SESSION["sid"] = $sid;   
                   	//if can successful login then set $_SESSION['chk'] = 1
                   	$_SESSION['chk'] = 1;
                   	$_SESSION['name'] = $uname[0];

                 	//define cookie and save password and sid into cookie
                   	if(isset($_POST['remember']))
                 	{
                       	setcookie('cid', $sid, time() + 3600);
                       	setcookie('cpswd', $password, time() + 3600);
                  	}
                  	else if(empty($_POST['remember']))
                 	{
	                  	//if the remember me checkbox is unchecked the cookie will destroy
	                   	setcookie('cid','');
	                   	setcookie('cpswd','');
                   	}
                                
                   	// Redirect user to profile page
                   	header("location: profile.php");
               	} 
               	else
               	{
                  	// Password is not valid, display a generic error message
                  	$login_err = "Invalid Student ID or password.";
               	}
             } 
          	else
        	{
             	// sid doesn't exist, display a generic error message
               	$login_err = "Invalid Student ID or password.";
          	}
       	}
      	else
      	{
         	if(!empty($sid_err) || !empty($password_err)){
				$login_err = "Please enter your student ID and password.";
			}
			else{
				echo "Oops! Something went wrong. Please try again later.";
			}
       	}

    }

    // Close connection
	mysqli_close($link);

?>
	 
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Student Login</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<style>
			body{ font: 14px sans-serif; background-image:url(images/login_back.jpg);}
			.wrapper{ width: 360px; padding: 20px; }
		</style>
	</head>
	<body>
		<div class="wrapper">
		<?php 
			if(!empty($login_err)){
				echo '<div class="alert alert-danger">' . $login_err . '</div>';
			}
		?>
			<h2>Student login</h2>
			<p>Please fill in your credentials to login.</p>

			
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" >
				<div>
					<a class="btn btn-warning" href="login.php">Student login</a>.
					<a class="btn btn-warning" href="admin.php">Teacher Login</a>.
				</div><br />
				<div class="form-group">
					<label>Student ID</label>
					<input type="text" name="sid" class="form-control <?php echo (!empty($sid_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $sid; ?>">
					<span class="invalid-feedback"><?php echo $sid_err; ?></span>
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?> " value="<?php echo $password; ?>">
					<span class="invalid-feedback"><?php echo $password_err; ?></span>
				</div>
					<label for="remeberMe">
						<div  class="form-group">
							<input type="checkbox" name="remember[]" class="btn btn-warning" <?php if(!empty($_COOKIE['cid'])) echo 'checked'; ?> > Remember me!
						</div>
					</label>
					
				<div class="form-group">
					<input type="submit" class="btn btn-warning" value="Login">
				</div>
				<p>New User? <a href="register.php">Register now</a>.</p>
				<p>Forgot Password? <a href="resetPwd.php">Reset now</a>.</p>
			</form>	
		</div>
	</body>
	</html>
<?php	
}
?>