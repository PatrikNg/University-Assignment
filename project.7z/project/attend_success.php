<?php
//when scan qrcode it will display these things
    echo "Attend successfull";

    $link=mysqli_connect('localhost','root','');
    mysqli_select_db($link, 'attendsystem');

    $date = $_GET['date'];
    $courseid = $_GET['courseid'];
    $studentname = $_GET['studentname'];
    $studentid = $_GET['studentid'];

    //go to table to find the student course section
    $sec = mysqli_query($link,"SELECT section FROM enrolledcourse WHERE studentid ='$studentid' AND courseid='$courseid'")or die( mysqli_error($link));
    $row1 = mysqli_fetch_row($sec);

    $section = $row1[0];

    //store the data into attend table when scan qrcode
    $update = mysqli_query($link,"UPDATE attend SET present='1', absent=null WHERE courseid='$courseid' AND section='$section' AND studentid='$studentid' AND date ='$date' ")or die(mysqli_error($connection));

    echo "<br />Date: ".$date."<br />Course ID: ";
    echo $courseid."<br />Student ID: ";
    echo $studentid."<br />Student Name: ";
    echo $studentname."<br />";

?>