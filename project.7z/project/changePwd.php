<?php
include("config.php");

	//if click back button then go to profile page.
	if(isset($_POST['back'])){
		header("location: profile.php");
	}
	
	
	
	if(isset($_POST['submit'])){
	$uid = $_POST['uid'];
	$oldPwd = $_POST['oldPwd'];
	$newPwd = $_POST['newPwd'];

	//password encryption
	//$hashed_OldPwd = password_hash($oldPwd,PASSWORD_DEFAULT);
	$hashed_NewPwd = password_hash($newPwd,PASSWORD_DEFAULT);
	//select matched data from database
	$query = mysqli_query($link,"SELECT * FROM student WHERE studentid LIKE'$uid' ")or die( mysqli_error($link));
	$Row = mysqli_fetch_row($query);
	
	
	//if the student id/ current password / the new password is entered then run
	if($uid!=null && $oldPwd!=null && $newPwd!=null)
	{
		if($Row==null)
		{
			$errorMessage = "Your are failed to change your password because of wrong uid or wrong password Entered.";
		}
		else
		{
			//If new password is not same with the current password then run
			if(password_verify($newPwd,$Row[3])!=1)
			{
				
				//if the old password matched the password stored into database then run
				if(password_verify($oldPwd,$Row[3])==1)
				{
					//update data to the database
					$update = mysqli_query($link, "UPDATE student SET password='$hashed_NewPwd' where studentid='$uid'");
					if($update)
					{
						$successMessage = "Your are succeed to change your password.";
					} 
					else 
					{
						echo 'Failed to edit record because '.mysqli_error();
					}
				}
				//if the old password are not matched the password stored into database then display
				else
				{
					$errorMessage = "Your are failed to change your password because of wrong uid or wrong password Entered.";
				}
				
			}
			//if new password is same with the current password then display
			else {
				$errorMessage = "You cannot use same password as your old password.";
				
			}
		}
	}
	//if the uid/ current password / the new password is not entered then display	
	else
	{
		$errorMessage = "Your need to enter your student ID, current password and the password you want to change to.";
	}
	
	mysqli_close($link);

	}
?>

<!DOCTYPE html>
<html>
<title>Change Password</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
		
        body{ 
		font: 14px sans-serif; 
		background-image:url(images/login_back.jpg);
		}
				
        #content{ 
		width: 360px;
		padding: 20px; 
		}
		
		#required{
			font-size:20px;
		}
    </style>
	
<body>

<div id="content">
		
		<?php 
        if(!empty($successMessage)){
            echo '<div class="alert alert-success">' . $successMessage . '</div>';
        }        
        ?>

		<?php 
        if(!empty($errorMessage)){
            echo '<div class="alert alert-danger">' . $errorMessage . '</div>';
        }        
        ?>

<form method="post" action="changePwd.php">
<input type="submit" name="back" value="Back" />
<h2>Change Password</h2>
<p style="color:blue;">Please enter your stundent ID, current password and new password.</p>	
<label id="required";>Student ID</label><br />
<input type="text" name="uid" class="form-control" /><br />
<label id="required";>Curent Password</label><br />
<input type="password" name="oldPwd" class="form-control" /><br />
<label id="required";>New Password</label><br />
<input type="password" name="newPwd" class="form-control" /><br />
<input type="submit" name="submit" value="Submit" class="btn btn-warning" /> &nbsp &nbsp
<button type="reset" class="btn btn-warning">Clear</button>

</form>
</body>

</html>