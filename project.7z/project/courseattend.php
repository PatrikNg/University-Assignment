<?php
require "design.php";
include("config.php");

//use session to get data
$stdname = $_SESSION['name'];
$sid = $_SESSION["sid"];

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;

//set the value to null
$todaydate_err = $todaydate = null;

//link to the database
$link=mysqli_connect('localhost','root','');
 mysqli_select_db($link, 'attendsystem');

}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student attendent list</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .Pro{text-align: center; font-size: 20px;}
        .ab{ text-align: center;font-size: 25px;}
        .word{text-align: center; font-size: 20px;margin-left: auto;margin-right: auto;}
  
    </style>
</head>
<body>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="Get">
    <div class="form-group">
    </div>
      	<?php
      		//get qrcode is open or not
			$qr = mysqli_query($link,"SELECT qrcode.open, qrcode.courseid, qrcode.section,qrcode.TodayDate FROM qrcode join enrolledcourse on enrolledcourse.courseid=qrcode.courseid WHERE open=1 and enrolledcourse.studentid='$sid' and qrcode.courseid=enrolledcourse.courseid and qrcode.section=enrolledcourse.section ")or die( mysqli_error($link));
			$qrc = mysqli_fetch_row($qr);

			//check if qrc has number or not
			if(!empty($qrc))
			{
				if($qrc['0']==1)
				{
					$qsec = $qrc['2'];
					$qcorid = $qrc['1'];

					//get student id
					$stid = mysqli_query($link,"SELECT studentid FROM student WHERE name ='$stdname'")or die( mysqli_error($link));
					$stuid = mysqli_fetch_row($stid);
					$id = $stuid['0'];

					//get if this student has attend this class or not
					$attst = mysqli_query($link,"SELECT studentid FROM enrolledcourse WHERE courseid ='$qcorid' AND studentid='$id' AND section='$qsec'")or die( mysqli_error($link));
					$row = mysqli_fetch_row($attst);

					if(!empty($row))
					{
						$attstu = $row['0'];
					
					

					//get course name
					$corna = mysqli_query($link,"SELECT coursename FROM course WHERE courseid ='$qcorid'")or die( mysqli_error($link));
					$course = mysqli_fetch_row($corna);
					$coursename = $course['0'];

					echo "Course name: ".$coursename."<br/>";
					echo "Course ID: ".$qcorid."<br/>";
					echo "Section: ".$qsec;
			?>
    </div>
</body>
</html>
		<?php
				//get the attend qrcode date
				$attdate = $qrc[3];
				// Include the qrlib file
				include 'phpqrcode/qrlib.php';
				$text = "http://assignment.ddns.net/project/attend_success.php?date=$attdate&courseid=$qcorid&studentname=$stdname&studentid=$attstu";
				  
				// $path variable store the location where to 
				// store image and $file creates directory name
				// of the QR code file by using 'uniqid'
				// uniqid creates unique id based on microtime
				$path = 'qrcode/';
				$file = $path.uniqid().".png";
				  
				// $ecc stores error correction capability('L')
				$ecc = 'L';
				$pixel_Size = 5;
				$frame_Size = 5;
				  
				// Generates QR Code and Stores it in directory given
				QRcode::png($text, $file, $ecc, $pixel_Size, $frame_Size);
				  
				// Displaying the stored QR code from directory
				echo "<center><img src='".$file."'></center>";
			}
			else
			{
				echo "Your Lecture haven't generate the QR code for attendance...";
			}
		}
		else
		{
			echo "Your Lecture haven't generate the QR code for attendance...";
		}
	}
	else
	{
		echo "Your Lecture haven't generate the QR code for attendance...";
	}
?>