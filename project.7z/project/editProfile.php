<?php
require "design.php";
include("config.php");

$sid = $_SESSION["sid"];

//retrieving data from database for displaying in the table below
$query = mysqli_query($link,"SELECT * FROM student where studentid='$sid' ")or die( mysqli_error($link));
$row = mysqli_fetch_row($query);

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;

}
	if(isset($_POST['submit'])){
		$successMsg=null;
		$erroMessage=null;
		$name=$_POST['name'];
		$phone=$_POST['phone'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$update = mysqli_query($link,"UPDATE student SET name='$name', phone='$phone', address='$address', email='$email' where studentid='$sid' ")or die( mysqli_error($link));
		
		if($update){
			$successMsg = "Profile updated successfully.";
			$query = mysqli_query($link,"SELECT * FROM student where studentid='$sid' ")or die( mysqli_error($link));
			$row = mysqli_fetch_row($query);
		}
		else{
			$erroMessage = "Faile to Update Profile";
		}
	}

	
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .Pro{text-align: center; font-size: 20px;}
        .ab{ text-align: center;font-size: 25px;}
        .word{text-align: center; font-size: 20px;margin-left: auto;margin-right: auto;}
  
    </style>
</head>
<body>
	<form action="editProfile.php" method="POST">
	<br/>
    <div>
        <table border="2" class="word" width="450px;" style="background-color:aquamarine;">
            <tr>
                <td colspan="2" class="ab" style="color:black;">Profile Edit</td>
            </tr>
            <tr>
                <td width="45%" style="text-align:left;color:#006400;" >Student Name:</td>
                <td class="Pro">
					<input type="text" size="25" name="name" value="<?php echo $row[2];?>" required> 
                </td>
            </tr>
            <tr>
                <td style="text-align:left;color:#0000FF;">Phone number:</td>
                <td>
                    
					<input type="tel" size="25" name="phone" value="<?php echo $row[4];?>" required>
                </td>
            </tr>
            <tr>
                <td style="text-align:left;color:#4B0082;">Address:</td>
                <td>
					<input type="text" size="25" name="address" value="<?php echo $row[5];?>" required> 
                </td>
            </tr>
            <tr>
                <td style="text-align:left;color:#9400D3;">Email:</td>
                <td>
					<input type="email" size="25" name="email" value="<?php echo $row[7];?>" required>
                </td>
            </tr>
			<tr>
				<td colspan="2">
					<input class="btn btn-warning" type="submit" name="submit" value="Submit" >
					<a href="profile.php" class="btn btn-warning ml-3">Back</a>
				</td>
			</tr>
        </table>
		
    </div>
	<div style="text-align:center;">
	<?php
		if(!empty($erroMessage)){
			echo '<div class="alert alert-danger">' . $erroMessage . '</div>';
		}
		
		if(!empty($successMsg)){
			echo '<div class="alert alert-success">' . $successMsg . '</div>';
		}
		?>
	<div>
	</form>
</body>
</html>