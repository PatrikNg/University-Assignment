<?php
//start the session
	session_start();

    //get the login name
    $tcname = $_SESSION['tname'];

    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true)
    {
        header("location: login.php");
        exit;
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{background-image:url(images/login_back.jpg);}
        .b{text-align: center; margin: 0px;padding: 1px; height: 100px; background-color: blue; font-style: italic; color: lightgreen  ; font-size: 50px; font-family: Apple Chancery, cursive;}
        .c{text-align: right; background-color: black; padding: 10px; font-family: Bookman, URW Bookman L, serif;}
    </style>
</head>
<body>
	<div class="b">
    	<h1 class="my-5">Welcome, <?php echo $_SESSION["tname"];?>.</h1>
    </div>
    <div class="c">
            <a href="attend.php" class="btn btn-warning ml-3">Take Attendance</a>
            <a href="report.php" class="btn btn-warning ml-3">Report</a>
            <a href="logout.php?teaname=$_SESSION['tname']" class="btn btn-warning ml-3">Log out</a>
        </div>
</body>
</html>