<?php
require "design.php";
include("config.php");

$sid = $_SESSION["sid"];
 
$student = mysqli_query($link,"SELECT * FROM student where studentid='$sid' ")or die( mysqli_error($link));
$studentData = mysqli_fetch_row($student);

$query = mysqli_query($link,"SELECT round(SUM(amount),2) FROM receipt where studentid='$sid'and amount-paid>0 ")or die( mysqli_error($link));
$row = mysqli_fetch_row($query);

if(empty($row[0])){
	$owe=0;
}
else{
	$owe=$row[0];
}

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;

}
	if(isset($_POST['paid'])){
		if($owe>0){
			header("location:makePay.php");
		}
		else{
			$errorMsg="You do not have any unpaid tuition fee.";
		}
	}

	
	
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .Pro{text-align: center; font-size: 20px;}
        .ab{ text-align: center;font-size: 25px;}
        .word{text-align: center; font-size: 20px;margin-left: auto;margin-right: auto;}
  
    </style>
</head>
<body>
<br/>
	<form action="paymentshow.php" method="POST">
    <div style="display:flex; justify-content:center;">

        <table border="2" width="35%" style="background-color:black;" >
            <tr>
                <td colspan="2" class="ab" style="color:red;">Payment</td>
            </tr>
			<tr>
                <td class="Pro" style="text-align:left;color:white;">Student ID:</td>
                <td class="Pro" style="text-align:left;color:white;">
				<?php if(!empty($row))echo $studentData[1];?>

                </td>
            </tr>
			 <tr>
                <td class="Pro"  style="text-align:left;color:white;" width="42%" >Student Name:</td>
                <td class="Pro" style="text-align:left;color:white;">
				<?php if(!empty($row))echo $studentData[2];?>

                </td>
            </tr>
			
			<tr>
                <td class="Pro" style="text-align:left;color:white;">Phone Number:</td>
                <td class="Pro" style="text-align:left;color:white;">
				<?php if(!empty($row))echo $studentData[4];?>

                </td>
            </tr>
			<tr>
                <td class="Pro" style="text-align:left;color:white;">Total Tuition Fee:</td>
                <td class="Pro" style="text-align:left;color:white;">
					<?php echo "RM".$owe;?>
                </td>
            </tr>
           

			<tr>
				<td colspan="2" class="ab" >
					<input class="btn btn-warning" type="submit" name="paid" value="Pay by Debit/Credit Card" >
				</td>
			</tr>
        </table>
		
    </div>
	<div style="text-align:center;">
		<?php 
        if(!empty($errorMsg)){
            echo '<div class="alert alert-danger">' . $errorMsg . '</div>';
        }        
		?>
	<div>
	</form>
</body>
</html>