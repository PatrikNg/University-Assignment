<?php
include("config.php");
	//if click back button then go to welcome page.
	if(isset($_POST['back'])){
		header("location: welcome.php");
	}
	
	
	
	if(isset($_POST['submit'])){
	$userName = $_POST['userName'];
	$oldPwd = $_POST['oldPwd'];
	$newPwd = $_POST['newPwd'];
	
	//password encryption
	//$hashed_OldPwd = password_hash($oldPwd,PASSWORD_DEFAULT);
	$hashed_NewPwd = password_hash($newPwd,PASSWORD_DEFAULT);
	//select matched data from database
	$query = mysqli_query($link,"SELECT * FROM users where userName='$userName' ")or die( mysqli_error($link));
	$Row = mysqli_fetch_row($query);
	
	
	//if the username/ current password / the new password is entered then run
	if($userName!=null && $oldPwd!=null && $newPwd!=null)
		if($Row==null){
			$errorMessage = "Your are failed to change your password because of wrong Username or wrong password Entered.";
		}
		else{
				//If new password is not same with the current password then run
			if(password_verify($newPwd,$Row[2])!=1){
				
				
				//first one is original password,second one is after encryption
				//if the old password matched the password stored into database then run
				if(password_verify($oldPwd,$Row[2])==1){
					//update data to the database
					$update = mysqli_query($link, "UPDATE users SET password='$hashed_NewPwd' where username='$userName'");
					if($update){
						$successMessage = "Your are succeed to change your password.";
					} else {
						echo 'Failed to edit record because '.mysqli_error();
					}
				}
				//if the old password are not matched the password stored into database then display
				else{
					$errorMessage = "Your are failed to change your password because of wrong Username or wrong password Entered.";
				}
				
			}
			//if new password is same with the current password then display
			else {
				$errorMessage = "You cannot use same password as your old password.";
				
			}
		}
	//if the username/ current password / the new password is not entered then display	
	else{
		$errorMessage = "Your need to enter your username, current password and the password you want to change to.";
	}
	
	
	mysqli_close($link);

	}
?>

<!DOCTYPE html>
<html>
<title>Change Password</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
		
        body{ 
		font: 14px sans-serif; 
		}
				
        #content{ 
		width: 360px;
		padding: 20px; 
		}
		
		#required{
			font-size:20px;
		}
		
    </style>
	
<body>

<div id="content">
		
		<?php 
        if(!empty($successMessage)){
            echo '<div class="alert alert-success">' . $successMessage . '</div>';
        }        
        ?>

		<?php 
        if(!empty($errorMessage)){
            echo '<div class="alert alert-danger">' . $errorMessage . '</div>';
        }        
        ?>

<form method="post" action="changePwd.php">
<input type="submit" name="back" value="Back" />
<h2>Change Password</h2>
<p>Please enter your username, current password and new password.</p>

<label id="required";>Username</label><br />
<input type="text" name="userName" class="form-control" /><br />
<label id="required";>Curent Password</label><br />
<input type="password" name="oldPwd" class="form-control" /><br />
<label id="required";>New Password</label><br />
<input type="password" name="newPwd" class="form-control" /><br />
<input type="submit" name="submit" value="Submit" class="btn btn-warning" /> &nbsp &nbsp
<button type="reset" class="btn btn-warning">Clear</button>
</form>
</body>

</html>