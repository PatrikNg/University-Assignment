<?php
	$newPwd=$_GET['newPwd'];
	if(isset($_POST['login'])){
		header("location:login.php");
		
	}
	if(isset($_POST['changePwd'])){
		header("location:changePwd.php");
	}

?>

	
	
<!DOCTYPE html>
<html>




<title>Reset Successfully</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<style>
	body{ 
		font: 14px sans-serif; 
	}
	
	#content{
		width: 363px;
		padding: 20px; 
	}
</style>
<body>
	<form action="resetted.php?newPwd=<?php echo $newPwd?>" method="POST">
	<div id="content">
	<div class="alert alert-primary">
	Your are succeed to reset your password, <?php echo $newPwd; ?> is your new password.
	<button id="copy" value="<?php echo $newPwd; ?>" onclick="jsCopyA()" class="btn btn-primary btn-sm" >Copy Password</button>
	<br />
	</div>
	<input type="submit" name="login" value="Login" class="btn btn-success" />
	<input type="submit" name="changePwd" value="Change Password" class="btn btn-success" />
	</div>
	</form>
	
<script>
function jsCopyA(){
	//getting the value of the button by ID
	var txt =document.getElementById("copy").value;
	//send the getting data to the clipboard
	navigator.clipboard.writeText(txt)
	//after copy to clipboard then will pop up
	.then(() => {
		alert("New password is copied.");
	});

}
</script>
	
</body>
</html>
