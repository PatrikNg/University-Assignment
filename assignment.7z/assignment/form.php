<?php
	include("config.php");
	session_start();
	//use the session getting the current username
	$user = $_SESSION["username"];
	
	// select all the data of current user from the database table users
	$query = mysqli_query($link,"SELECT * FROM users where username='$user' ")or die( mysqli_error($link));
	$row = mysqli_fetch_row($query);
	
	//getting the food name from food table when it is found the food ID on the favorfood table based on the current user's ID
	$favor = mysqli_query($link,"SELECT food.foodName FROM food join favorfood on favorfood.foodID = food.foodID where favorfood.id = '$_SESSION[id];'")or die( mysqli_error($link));
	$find = mysqli_fetch_row($favor);
	
	//getting the eye colour from eye table when it is found the eye ID on the eyecolor table based on the current user's ID
	$eyeColor = mysqli_query($link,"SELECT eye.eyeColors FROM eye join eyecolor on eyecolor.eyeID = eye.eyeID where eyecolor.id = '$_SESSION[id];'")or die( mysqli_error($link));
	$findEye = mysqli_fetch_row($eyeColor);
	
	//for getting favourite food, if not empty will run
	if(!empty($find)){
		$i=0;

		do
		{	//store all the favourite food getting from the database in to the $favorF array
			$favorF[$i]=$find[0];
			$i++;
		$find = mysqli_fetch_row($favor);
		
		}while($find);	

	}
	//for getting eye color, if not empty will run
	if(!empty($findEye)){
		$k=0;

		do
		{	//store all the eye colour getting from the database in to the $eyeColour array
			$eyeColour[$k]=$findEye[0];
			$k++;
		$findEye = mysqli_fetch_row($eyeColor);
		}while($findEye);	

	}
	
	
	//include required phpmailer files
	require 'email\src\Exception.php';
	require 'email\src\PHPMailer.php';
	require 'email\src\SMTP.php';
					
	//define name spaces
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;
	
	
	if(isset($_POST['submit'])){
		
		//getting the password from the database based on current user's id
		$query = mysqli_query($link,"SELECT password FROM users where id='$_SESSION[id];' ")or die( mysqli_error($link));
		$DBpwd = mysqli_fetch_row($query);
		
		//verify the user entered password with the hashed password
		if(password_verify($_POST['password'],$DBpwd[0])==1){
			
			//if the things display below is not empty will run
			if(!empty($_POST['favorfood']) & !empty($_POST['eyeColor'])&!empty($_POST['gender'])&!empty($_FILES['file']['name'])){
				
			//getting data from post method
			$actName=$_POST['name'];
			$email=$_POST['email'];
			$age=$_POST['age'];
			$birthD=$_POST['date'];
			
			
			//insert favorite food into database table
			//if favourite food selected
			if(!empty($_POST['favorfood'])){
				//delete all the data stored in database table favorfood based on current user's Id
				mysqli_query($link,"DELETE FROM favorfood where favorfood.id = '$_SESSION[id];'" )or die( mysqli_error($link));
				
				//kept looping for inserting data
				foreach($_POST['favorfood'] as $update){
					//getting the foodId of specific food based on selected foodname from the database table food
					$favorFoodGet = mysqli_query($link,"SELECT foodID FROM food where foodName = '$update'");
					//getting the foodID
					$foodID = mysqli_fetch_row($favorFoodGet);
					//insert the user's ID and foodID into database table favorfood, if error will print error message
					mysqli_query($link,"INSERT INTO favorfood VALUES ('$_SESSION[id];','$foodID[0]') ")or die( mysqli_error($link));
				}
			}
			
			//insert eyecolor into database table
			//if eye color selected
			if(!empty($_POST['eyeColor'])){
				//delete all the data stored in database table eyecolor based on current user's Id
				mysqli_query($link,"DELETE FROM eyecolor where eyecolor.id = '$_SESSION[id];'" )or die( mysqli_error($link));

				//kept looping for inserting data
				foreach($_POST['eyeColor'] as $update2){
					//getting the eyeId of specific colour based on selected eyeColors from the database table eye
					$eyeColorGet = mysqli_query($link,"SELECT eyeID FROM eye where eyeColors = '$update2'");
					//getting the eye id
					$eyeID = mysqli_fetch_row($eyeColorGet);
					//insert the user's ID and eyeID into database table eyecolor, if error will print error message
					mysqli_query($link,"INSERT INTO eyecolor VALUES ('$_SESSION[id];','$eyeID[0]') ")or die( mysqli_error($link));
				}
			}
			
			//getting data from post method
			$gender=$_POST['gender'];
			$bio=$_POST['bio'];
			$phone=$_POST['phone'];
			$url=$_POST['url'];
			$color=$_POST['color'];
			//make the array to be a string by implode method
			$UserFavorFood=implode(", ",$_POST['favorfood']);
			$UserEyeColor=implode(", ",$_POST['eyeColor']);
			
			//check user gender and decide to use Mr. or Ms. when sending email
			$gender=$_POST['gender'];
			if($gender=="male"){
				$userGender="Mr.";
			}
			else{
				$userGender="Ms.";
			}
			

			$file=$_FILES['file'];
			//getting file name
			$fileName = $_FILES['file']['name'];
			//getting temporary location of the file
			$fileTmpName = $_FILES['file']['tmp_name'];
			//getting error when uploading, will be used for checking whether error happened or not
			$fileError = $_FILES['file']['error'];
			//getting file size, will be used for checking the file size
			$fileSize =$_FILES['file']['size'];
			
			//getting file data
			//mysqli_real_escape_string() is used for storing special data type
			$fileData= mysqli_real_escape_string($link,file_get_contents($fileTmpName));

			
			//if file do not have error on uploading will process next
			if($fileError === 0){
				//if file is small than this size will  process next
				if($fileSize < 1048576 ){
					
					//update the data to the database
					$updateUser = mysqli_query($link,"UPDATE users SET name='$actName', phone='$phone', email='$email', age='$age', birthdate='$birthD', gender='$gender', bio='$bio', file='$fileData', url='$url', color='$color' WHERE id='$_SESSION[id];'");
					if($updateUser){
						
						
						//after success sending email
							
							//create instance of phpmailer
							$mail = new PHPMailer();
							
							//set mailer to user smtp
							$mail -> isSMTP();
							
							//define smtp host
							$mail -> Host = "smtp.gmail.com";
							
							//enable smtp authentication
							$mail -> SMTPAuth = TRUE;
							
							//set type of encryption (ssl/tls)
							$mail -> SMTPSecure = "tls";
							
							//set port to connect smtp
							$mail -> Port = 587;
							
							//set gmail username
							$mail -> Username = "phpMyAssignment@gmail.com";
							
							//set gmail password
							$mail -> Password = "php_1234";
							
							//set emai subject
							$mail -> Subject = "Form Submission by $actName ";
							
							//set sender email
							$mail -> setfrom("phpMyAssignment@gmail.com");
							
							//enable HTML format in email
							$mail-> isHTML(true);
							
							//email body
							$mail ->Body = "<h1>Form From $actName</h1>
											 <table width=300px border=1> 
											 <tr>
											 <td>Name</td>
											 <td>$actName</td>
											 </tr>
											 <tr>
											 <td>Email</td>
											 <td>$email</td>
											 </tr>
											 <tr>
											 <td>Age</td>
											 <td>$age</td>
											 </tr>
											 <tr>
											 <td>Birthdate</td>
											 <td>$birthD</td>
											 </tr> 
											 <tr>
											 <td>Favourite Food</td>
											 <td>$UserFavorFood</td>
											 </tr>
											 <tr>
											 <td>Eye Color</td>
											 <td>$UserEyeColor</td>
											 </tr>
											 <tr>
											 <td>Bio</td>
											 <td>$bio</td>
											 </tr>
											 <tr>
											 <td>File</td>
											 <td>$fileName</td>
											 </tr>
											 <tr>
											 <td>Phone</td>
											 <td>$phone</td>
											 </tr>
											 <tr>
											 <td>URL</td>
											 <td>$url</td>
											 </tr>
											 <tr>
											 <td>Selected Colour</td>
											 <td style='background-color:$color'></td>
											 </tr>
											 </table>";
							
							//add attachment for sending file
							$mail->addAttachment($fileTmpName,$fileName);
							
							//add recipient
							$mail -> addAddress("phpMyAssignment@gmail.com");
							
							//finally send email
							if($mail -> Send())
							{
							}
							else
							{
								echo "Error ..!". $mail->ErrorInfo;
							}
							
							//this is for remove previous recipient
							$mail->ClearAllRecipients();
							
							//this is for removing attachment
							$mail->ClearAttachments();
							
							//set emai subject
							$mail -> Subject = "Thank you for your replying.";
							
							//set sender email
							$mail -> setfrom("phpMyAssignment@gmail.com");
							
							//email body
							$mail ->Body = "$userGender$actName. Thank you for your replying.";
							
							//add recipient
							$mail -> addAddress("$email");
							
							//finally send email
							if($mail -> Send())
							{
								echo "Email Sent.5.!";
							}
							else
							{
								echo "Error ..!". $mail->ErrorInfo;
							}
							
							//closing smtp connection
							$mail -> smtpClose();	
								
							//go to welcome page.
							header("Location:welcome.php");
							
					} else {
						$errorMsg = 'Failed to edit record because '.mysqli_error($link);
					}
				}
				else{
					if($_FILES['file']['type']!="application/octet-stream"){
						
					}
					$errorMsg = "Your files is too big!";
					
				}
			}
			else{
				$errorMsg = "There was an error uploading your file!";
				
			}

			
				
			}
			else{
				$errorMsg ="You need to enter all the things and upload a file before submitting.";
				
			}
		}
		else{
			$errorMsg = "Your Enter a wrong password!";

		}
	}

?>
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
		body{background-image:url(background.gif); }
		#head{text-align:center; background-color:aquamarine; }
        .content{ font: 14px sans-serif; justify-content:center; padding:50px; display:flex; }
		#cont{text-align: left; width:330px; padding:10px; border:1px solid; background-color:white;}
</style>
<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie-edge" />
    <title>Form</title>
	
</head>
<body>
<div class="content">

	
	
	<div id="cont">
	<?php 
        if(!empty($errorMsg)){
            echo '<div class="alert alert-danger">' . $errorMsg . '</div>';
        }        
    ?>
    <form action="form.php" method="post" enctype="multipart/form-data">
	<div id="head"><h1>Please Fill In The Form</h1><br/></div><br/>
        <div>
            <label for="name" >Name</label>
            <input type="text" name="name" id="name" value="<?php echo $row[8];?>" required>
        </div>
        <div>
            <label for="email">Email</label>
            <input type="email" name="email" id="email" value="<?php echo $row[4];?>" required>
        </div>
        <div>
            <label for="age">Age</label>
            <input type="number" name="age" id="age" value="<?php echo $row[5];?>" min="1" max="200" step="1">
        </div>
        <div>
            <label for="date">Birthdate</label>
            <input type="date" name="date" id="date" value="<?php echo $row[6];?>" min="1900-06-10" >
        </div>
        <div>
            Favorite Food
            <div>
                <input type="checkbox" id="food" name="favorfood[]" value="banana" <?php if(!empty($favorF)){if(in_array('banana',$favorF)) echo "checked";}?>>
				<label for="banana">Banana</label>
            </div>
            <div>
				<input type="checkbox" id="food" name="favorfood[]" value="apple" <?php if(!empty($favorF)){if(in_array('apple',$favorF)) echo "checked";}?> >
                <label for="apple">Apple</label>
            </div>
			<div>
				<input type="checkbox" id="food" name="favorfood[]" value="watermelon" <?php if(!empty($favorF)){if(in_array('watermelon',$favorF)) echo "checked";}?> >
                <label for="watermelon">Watermelon</label>
            </div>
        </div>
        <div>
            Gender
            <div>
                <input type="radio" name="gender" id="male" value="male" <?php if($row[7]=="male") echo "checked";?>>
				<label for="male">Male</label>
            </div>
            <div>
                <input type="radio" name="gender" id="male" value="female" <?php if($row[7]=="female") echo "checked";?>>
				<label for="female">Female</label>
            </div>
        </div>
        <div>
            <label for="eyeColor">Eye Color</label>
            <select name="eyeColor[]" id="eyeColor" multiple >
                <option value="green" <?php if(!empty($eyeColour)){if(in_array('green',$eyeColour)) echo "selected";}?> >Green</option>
                <option value="red" <?php if(!empty($eyeColour)){if(in_array('red',$eyeColour)) echo "selected";}?> >Red</option>
				<option value="grey" <?php if(!empty($eyeColour)){if(in_array('grey',$eyeColour)) echo "selected";}?> >Grey</option>
				<option value="brown" <?php if(!empty($eyeColour)){if(in_array('brown',$eyeColour)) echo "selected";}?> >Brown</option>
				<option value="black" <?php if(!empty($eyeColour)){if(in_array('black',$eyeColour)) echo "selected";}?> >Black</option>
            </select>
        </div>
        <div>
            <label for="bio">Bio</label>
            <textarea id="bio" name="bio" value="<?php echo $row[9];?>" ><?php echo $row[9];?></textarea>
        </div>
        <input type="hidden" name="hidden" value="hi">
        <div>
            <label for="file">File</label>
            <input id="file" type="file" name="file" >
        </div>
        <div>
            <label for="phone">Phone</label>
            <input type="tel" name="phone" id="phone" value="<?php echo $row[3];?>" >
        </div>
        <div>
            <label for="url">URL</label>
            <input type="url" name="url" id="url" value="<?php echo $row[11];?>" >
        </div>
        <div>
            <label for="color">Color</label>
            <input type="color" name="color" id="color" value="<?php echo $row[12]; ?>">
        </div>
        <div>
            <label>
                Password
                <input type="password" name="password" required >
            </label>
        </div>
        <button type="reset">Reset</button>
        <button type="submit" name="submit">Submit</button>
    </form>
	</div>
</div>
</body>
</html>
