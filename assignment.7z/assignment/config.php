<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'loginsystem');


//connect to the phpmyadmin
$conn=mysqli_connect("localhost","root",'');
//check the connection
if(!$conn){
	die("connection error".mysqli_error($conn));
}
//searching for this database
$db=mysqli_select_db($conn,"loginsystem");

//checking the searching database is created or not
if(empty($db)){
	//if not found then create
	//create database
	$create = "CREATE DATABASE loginsystem";
	//checking whether database is created successfully or not
	if(mysqli_query($conn,$create)){
		
		/* Attempt to connect to MySQL database */
	$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
	// Check connection
	if($link === false){
		die("ERROR: Could not connect. " . mysqli_connect_error($link));
	}
	
	
	//select all from table
	$table="SELECT * FROM users";
	//checking table if no then create
	if(!mysqli_query($link,$table)){

		$create1="CREATE TABLE users(
		id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		username varchar(50) NOT NULL UNIQUE KEY,
		password varchar(255) NOT NULL,
		phone varchar(255) NOT NULL,
		email varchar(255) NULL,
		age int(3) NULL,
		birthdate date NULL,
		gender varchar(6) NULL,
		name varchar(50) NOT NULL,
		bio varchar(600) NULL,
		file longblob NULL,
		url varchar(100) NULL,
		color varchar(10) NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create1)){
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table2="SELECT * FROM food";
	if(!mysqli_query($link,$table2)){

		$create2="CREATE TABLE food(
		foodID int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		foodName varchar(50) NOT NULL
		)";
	//check whether created or fail	
		if(mysqli_query($link,$create2)){
						
			//insert data into food table
			$insertData2 =
			"INSERT INTO food VALUES
			('','banana'),
			('','apple'),
			('','watermelon')";
			if(mysqli_query($link,$insertData2)){
				
			}
			else{
				echo mysqli_error($link);
			}
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table3="SELECT * FROM favorfood";
	if(!mysqli_query($link,$table3)){

		$create3="CREATE TABLE favorfood(
		id int(11) NOT NULL,
		FOREIGN KEY(id) REFERENCES users(id),
		foodID int(11) NOT NULL,
		FOREIGN KEY(foodID) REFERENCES food(foodID)
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create3)){
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
		

	//select all item from this table
	$table4="SELECT * FROM eye";
	if(!mysqli_query($link,$table4)){

		$create4="CREATE TABLE eye(
		eyeID int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		eyeColors varchar(50) NOT NULL
		)";
	//check whether created or fail	
		if(mysqli_query($link,$create4)){
			//insert data into eye table
			$insertData =
			"INSERT INTO eye VALUES
			('','green'),
			('','red'),
			('','grey'),
			('','brown'),
			('','black')";
			if(mysqli_query($link,$insertData)){
				
			}
			else{
				echo mysqli_error($link);
			}
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table5="SELECT * FROM eyeColor";
	if(!mysqli_query($link,$table5)){

		$create5="CREATE TABLE eyeColor(
		id int(11) NOT NULL,
		FOREIGN KEY(id) REFERENCES users(id),
		eyeID int(11) NOT NULL,
		FOREIGN KEY(eyeID) REFERENCES eye(eyeID)
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create5)){
			
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	//error message when fail to create database
	}
	else{
		echo "Error creating database: " . mysqli_error($conn);
	}
}
else{
	/* Attempt to connect to MySQL database */
	$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
	// Check connection
	if($link === false){
		die("ERROR: Could not connect. " . mysqli_connect_error());
	}
	//select all from table
	$table="SELECT * FROM users";
	//checking table if no then create
	if(!mysqli_query($link,$table)){

		$create1="CREATE TABLE users(
		id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		username varchar(50) NOT NULL UNIQUE KEY,
		password varchar(255) NOT NULL,
		phone varchar(255) NOT NULL,
		email varchar(255) NULL,
		age int(3) NULL,
		birthdate date NULL,
		gender varchar(6) NULL,
		name varchar(50) NOT NULL,
		bio varchar(600) NULL,
		file longblob NULL,
		url varchar(100) NULL,
		color varchar(10) NULL
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create1)){
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table2="SELECT * FROM food";
	if(!mysqli_query($link,$table2)){

		$create2="CREATE TABLE food(
		foodID int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		foodName varchar(50) NOT NULL
		)";
	//check whether created or fail	
		if(mysqli_query($link,$create2)){
			
			//insert data into food table
			$insertData2 =
			"INSERT INTO food VALUES
			('','banana'),
			('','apple'),
			('','watermelon')";
			if(mysqli_query($link,$insertData2)){
				
			}
			else{
				echo mysqli_error($link);
			}
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table3="SELECT * FROM favorfood";
	if(!mysqli_query($link,$table3)){

		$create3="CREATE TABLE favorfood(
		id int(11) NOT NULL,
		FOREIGN KEY(id) REFERENCES users(id),
		foodID int(11) NOT NULL,
		FOREIGN KEY(foodID) REFERENCES food(foodID)
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create3)){
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table4="SELECT * FROM eye";
	if(!mysqli_query($link,$table4)){

		$create4="CREATE TABLE eye(
		eyeID int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		eyeColors varchar(50) NOT NULL
		)";
	//check whether created or fail	
		if(mysqli_query($link,$create4)){
			
			//insert data into eye table
			$insertData =
			"INSERT INTO eye VALUES
			('','green'),
			('','red'),
			('','grey'),
			('','brown'),
			('','black')";
			if(mysqli_query($link,$insertData)){
				
			}
			else{
				echo mysqli_error($link);
			}
			
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}
	
	//select all item from this table
	$table5="SELECT * FROM eyeColor";
	if(!mysqli_query($link,$table5)){

		$create5="CREATE TABLE eyeColor(
		id int(11) NOT NULL,
		FOREIGN KEY(id) REFERENCES users(id),
		eyeID int(11) NOT NULL,
		FOREIGN KEY(eyeID) REFERENCES eye(eyeID)
		)";
		//check whether created or fail	
		if(mysqli_query($link,$create5)){
		}
		else{
			echo "Error creating database table: " . mysqli_error($link);
		}
	}

}
?>
