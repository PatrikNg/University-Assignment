<?php
//start the session
	session_start();

    //get the login name
    $stname = $_SESSION['name'];

    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true)
    {
        header("location: login.php");
        exit;
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{background-image:url(images/login_back.jpg);}
        .b{text-align: center; margin: auto;padding: 1px; background-color: blue; font-style: italic; color: lightgreen  ; font-size: 50px;}
        .c{text-align: right; background-color: black;padding: 10px;}
    </style>
</head>
<body>
	<div class="b">
    	<h1 class="my-5">Welcome, <?php echo $_SESSION['name'];?>.</h1>
    </div>
        <div class="c">
            <a href="profile.php" class="btn btn-warning ml-3">Profile</a>           
	       <a href="timetable.php" class="btn btn-warning ml-3">Time Table</a>
           <a href="courseattend.php" class="btn btn-warning ml-3">Course Attendent</a>
	       <a href="enroll.php" class="btn btn-warning ml-3">Enrollment</a>
	       <a href="paymentshow.php" class="btn btn-warning ml-3">Payment</a>
            <a href="logout.php?stuname=$_SESSION['name']" class="btn btn-warning ml-3">Log out</a>
        </div>
</body>
</html>