<?php
require "design.php";
include("config.php");

$sid = $_SESSION["sid"];

$link=mysqli_connect('localhost','root','');
 mysqli_select_db($link, 'attendsystem');

$query = mysqli_query($link,"SELECT * FROM student where studentid='$sid' ")or die( mysqli_error($link));
$row = mysqli_fetch_row($query);
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;

}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .Pro{text-align: center; font-size: 20px;}
        .ab{ text-align: center;font-size: 25px;}
        .word{text-align: center; font-size: 20px;margin-left: auto;margin-right: auto;}
  
    </style>
</head>
<body>
    <div>
        <table border="2" class="word">
            <tr>
                <td colspan="2" class="ab">Profile</td>
            </tr>
            <tr>
                <td>Student ID:</td>
                <td>
                    <?php echo $row[1];?>
                </td>
            </tr>
            <tr>
                <td>Name:</td>
                <td class="Pro">
                    <?php echo $row[2]; ?>
                </td>
            </tr>
            <tr>
                <td>Phone number:</td>
                <td>
                    <?php echo $row[4];?>
                </td>
            </tr>
            <tr>
                <td>Address:</td>
                <td>
                    <?php echo $row[5];?>
                </td>
            </tr>
            <tr>
                <td>Nation:</td>
                <td>
                    <?php echo $row[6];?>
                </td>
            </tr>
                <tr>
                <td>Email:</td>
                <td>
                    <?php echo $row[7];?>
                </td>
            <tr>
                <tr>
                <td>Enrollment Year:</td>
                <td>
                    <?php echo $row[8];?>
                </td>
            </tr>
            <tr>
                <td>Gender:</td>
                <td>
                    <?php echo $row[9];?>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="changePwd.php">Change Password</a>
                </td>
                <td>
                    <a href="editProfile.php">Edit Profile</a>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>