 <!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Report</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<style>
			body{ font: 14px sans-serif; background-image:url(images/login_back.jpg);}
			.wrapper{ width: 360px; padding: 20px; }
		</style>
	</head>
	<body>
		<div class="wrapper">
		
			<h2>Attandance report</h2>
			

			
			<form action="report.php" method="get" >
				<div class="form-group">
					<label>Date</label>
					<input type="date" name="attandate" class="form-control" value="">

				</div>
				<div class="form-group">
					<label>CourseID</label>
					<input type="text" name="courseid" class="form-control" value="">
					
				</div>
                <div class="form-group">
					<label>Section</label>
					<input type="text" name="section" class="form-control" value="">
					
				</div>
					
					
				<div class="form-group">
					<input type="submit" name="submit" class="btn btn-warning" value="Generate">
				</div>
				
			</form>	
		</div>
	</body>
	</html>
<?php  
require_once "config.php";
error_reporting (0);
$isChart = 0;
$date=$_GET['attandate'];
$courseID=$_GET['courseid'];
$Section=$_GET['section'];

$query = "SELECT absent,count(*) as number FROM attend where date='$date' and courseid='$courseID' and section='$Section' GROUP BY absent";
$result = mysqli_query($link, $query); 

 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Report</title> 
          
          <style>
			body{ font: 14px sans-serif; background-image:url(images/login_back.jpg);}
			.wrapper{ width: 360px; padding: 20px; }
		</style>
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript">    
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['absent', 'number'],
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  if ($row["absent"] == 1){
                               echo "['Absent', ".$row["number"]."],";
                              $isChart = 1;
                            }else{
                              echo "['Present', ".$row["number"]."],";
                              $isChart = 1;
                          }
                          }  
                          ?>  
                     ]);  
                var options = {  
                      title: 'Percentage of absent',  
                      //is3D:true,  
                      pieHole: 0.3 
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  
           } 
               
           </script> 
          
      </head>  
      <body>  
           <br /><br />  
           <div style="width:1000px;">  
               
                
               
           
             <br /> 
               <?php if($isChart == 1){
                echo "<h1 align=center>Report</h1>";
                echo "<h4> Date: $date </h4>";
                echo "<h4> Course: $courseID </h4>";
                echo "<h4> Section: $Section</h4>"; 
    
                echo '<div id="piechart" style="width: 1000px; height: 500px;"></div>'; 
                }
               else
               echo"There is no data"
               ?>
           </div>  
      </body>  
 </html> 