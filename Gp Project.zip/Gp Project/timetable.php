	<?php
require "design.php";
include("config.php");

$sid = $_SESSION["sid"];

	
	$getDate = mysqli_query($link,"Select * from coursedetail join enrolledcourse on enrolledcourse.courseid = coursedetail.courseid where enrolledcourse.studentid='$sid' and coursedetail.section=enrolledcourse.section ") or die(mysqli_error($link));
	$getted = mysqli_fetch_array($getDate);
	
	$wd1 =array();
	$wd2 =array();
	$wd3 =array();
	$wd4 =array();
	$wd5 =array();
	if(!empty($getted)){
		do{
			$cNsection = "$getted[0] $getted[1]";
			if($getted[3]==1){
				$wd1 +=array($getted[4]=>$cNsection);
				$wd1 +=array(date("H:i:s",strtotime($getted[4])+strtotime($getted[5]))=>$cNsection);
			}
			else if($getted[3]==2){
				$wd2 +=array($getted[4]=>$cNsection);
				$wd2 +=array(date("H:i:s",strtotime($getted[4])+strtotime($getted[5]))=>$cNsection);
			}
			else if($getted[3]==3){
				$wd3 +=array($getted[4]=>$cNsection);
				$wd3 +=array(date("H:i:s",strtotime($getted[4])+strtotime($getted[5]))=>$cNsection);
			}
			else if($getted[3]==4){
				$wd4 +=array($getted[4]=>$cNsection);
				$wd4 +=array(date("H:i:s",strtotime($getted[4])+strtotime($getted[5]))=>$cNsection);
			}
			else if($getted[3]==5){
				$wd5 +=array($getted[4]=>$cNsection);
				$wd5 +=array(date("H:i:s",strtotime($getted[4])+strtotime($getted[5]))=>$cNsection);
			}
					
			
			$getted = mysqli_fetch_array($getDate);

		}while($getted);
	}

	
	
?>




 
<!DOCTYPE html>
<html lang="en">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<head>
    <meta charset="UTF-8">
    <title>Time Table</title>
</head>
<body>
<br/>
	<form action="timetable.php" method="POST">
	
<?php
$getCData = mysqli_query($link,"Select distinct coursedetail.courseid, course.coursename, lecturer.name,coursedetail.section from coursedetail join enrolledcourse on enrolledcourse.courseid = coursedetail.courseid join lecturer on lecturer.lecturerid=coursedetail.lecturerid join course on course.courseid=coursedetail.courseid where enrolledcourse.studentid='$sid' and coursedetail.section=enrolledcourse.section ") or die(mysqli_error($link));
	$CDataGtted = mysqli_fetch_row($getCData);
	if(!empty($CDataGtted)){
		echo "<div style='margin-left:21%; display:flex;'><table>";
		echo "<th>No</th><th>Course ID</th><th>Course Name</th><th>Lecturer</th><th>Section</th>";
		$i=1;
		do{
			echo "<tr>";
			echo "<td style='padding-right:25px;'>$i</td>";
			echo "<td style='padding-right:25px;'>$CDataGtted[0]</td>";
			echo "<td style='padding-right:20px;'>$CDataGtted[1]</td>";
			echo "<td style='padding-right:40px;'>$CDataGtted[2]</td>";
			echo "<td>$CDataGtted[3]</td>";
			$i++;
			echo "</tr>";
			$CDataGtted = mysqli_fetch_row($getCData);
		}while($CDataGtted);
		echo "</table></div>";
	}

?>
<br/>
<div style="justify-content:center; display:flex;">



<table border="2px solid" style="border-color:black;" width=910px; >
<tr style="background-color:white;">
<td></td>
<?php
	$begin=date("08:00");
	while($begin<=date("20:00")){
		echo "<td style='width:70px;'>$begin</td>";
		$begin =date("H:i",strtotime($begin)+strtotime(date("02:00")));
	}
?>
</tr>

<tr style="background-color:#FF0000;color:white;">
<td style="width:30px;">MON</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		if(array_key_exists($begin,$wd1)){
			foreach($wd1 as $Ctime=>$Cdetail){
				if($Ctime==$begin){
					echo "<td>$Cdetail</td>";
				}
			}
		}
		else{
			echo "<td></td>";
		}
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>

<tr style="background-color:#FF7F00;color:white;">
<td>TUE</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		if(array_key_exists($begin,$wd2)){
			foreach($wd2 as $Ctime=>$Cdetail){
				if($Ctime==$begin){
					echo "<td>$Cdetail</td>";
				}
			}
		}
		else{
			echo "<td></td>";
		}
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
	
?>
</tr>



<tr style="background-color:#FFFF00;color:black;">
<td>WED</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		if(array_key_exists($begin,$wd3)){
			foreach($wd3 as $Ctime=>$Cdetail){
				if($Ctime==$begin){
					echo "<td>$Cdetail</td>";
				}
			}
		}
		else{
			echo "<td></td>";
		}
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>


<tr style="background-color:#00FF00;color:black;">
<td>THU</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		if(array_key_exists($begin,$wd4)){
			foreach($wd4 as $Ctime=>$Cdetail){
				if($Ctime==$begin){
					echo "<td>$Cdetail</td>";
				}
			}
		}
		else{
			echo "<td></td>";
		}
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>



<tr style="background-color:#0000FF;color:white;">
<td>FRI</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		if(array_key_exists($begin,$wd5)){
			foreach($wd5 as $Ctime=>$Cdetail){
				if($Ctime==$begin){
					echo "<td>$Cdetail</td>";
				}
			}
		}
		else{
			echo "<td></td>";
		}
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>

<tr style="background-color:#4B0082;color:white;">
<td>SAT</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		echo "<td></td>";
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>

<tr style="background-color:#9400D3;color:white;">
<td>SUN</td>
<?php
	$begin=date("08:00:00");
	while($begin<=date("20:00:00")){
		echo "<td></td>";
		$begin =date("H:i:s",strtotime($begin)+strtotime(date("02:00:00")));
	}
?>
</tr>

</table>
</div>
<br/>
</body>
</html>