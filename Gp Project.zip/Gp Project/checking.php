<?php

	//include required phpmailer files
	require 'email\src\Exception.php';
	require 'email\src\PHPMailer.php';
	require 'email\src\SMTP.php';
					
	//define name spaces
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;

	$lID = $_SESSION["id"];;
	$cID = $_POST['courseid'];;
	$section = $_POST['section'];

	$getWDay = mysqli_query($link,"SELECT weekday FROM coursedetail where lecturerid='$lID' and courseid='$cID' and section='$section' ");
	$wday = mysqli_fetch_row($getWDay) or die (mysqli_error($link));
	$total=0;
	if(!empty($wday)){

		do
		{	
		
		$total += calTotal($wday[0]);
		$wday = mysqli_fetch_row($getWDay);
		}while($wday);	
		
	}
	$Warning =array();
	
	//$updating = mysqli_query($connection,"update attend set present='1', absent=null where courseid='$cID' and section='$section' ")or die(mysqli_error($connection));
	$updating = mysqli_query($link,"update attend set absent='1' where courseid='$cID' and section='$section' and present is null ")or die(mysqli_error($link));
	//$updating = mysqli_query($connection,"update attend set absent=null where courseid='$cID' and section='$section' and absent is not null ")or die(mysqli_error($connection));
	
	$getStudent = mysqli_query($link,"SELECT distinct studentid from attend where courseid='$cID' and section='$section'")or die(mysqli_error($link));
	$studentid = mysqli_fetch_row($getStudent);
	
	if(!empty($studentid)){

		do{
			$check = mysqli_query($link,"SELECT count(absent) from attend where courseid='$cID' and section='$section' and studentid='$studentid[0]' ")or die(mysqli_error($link));
			$checkResult = mysqli_fetch_row($check);
			$cal = $checkResult[0];

			if(($cal/$total*100)>20){
				$emailGet = mysqli_query($link,"SELECT name,email from student where studentid='$studentid[0]'")or die(mysqli_error($link));
				$emailData = mysqli_fetch_row($emailGet);

				$Warning +=array($emailData[1]=>$emailData[0]);
			}
			
			
			$studentid = mysqli_fetch_row($getStudent);
		}while($studentid);
		
	}
	
	
	function calTotal($weekDay){

		$startDate = strtotime(date("y-m-01"));
		$endDate = strtotime(date("y-m-t"));

		
		$totalDate=0;
		while($startDate<=$endDate){

		$what=date("N",$startDate);
			if($what==$weekDay){
				$totalDate++;
			}
			$startDate +=86400;
		}
		return $totalDate;
	}
	
	
	if(!empty($Warning)){
		foreach ($Warning as $k=>$v){
			
			//create instance of phpmailer
			$mail = new PHPMailer();
							
			//set mailer to user smtp
			$mail -> isSMTP();
							
			//define smtp host
			$mail -> Host = 'smtp.gmail.com';
							
			//enable smtp authentication
			$mail -> SMTPAuth = TRUE;
							
			//set type of encryption (ssl/tls)
			$mail -> SMTPSecure = "tls";
							
			//set port to connect smtp
			$mail -> Port = 587;
							
			//set gmail username
			$mail -> Username = "phpMyAssignment@gmail.com";
							
			//set gmail password
			$mail -> Password = "php_1234";
							
			//set emai subject
			$mail -> Subject = "Warning Letter From Course $cID $section";
							
			//set sender email
			$mail -> setfrom("phpMyAssignment@gmail.com");
							
			//enable HTML format in email
			$mail-> isHTML(true);
							
			//email body
			$mail ->Body = "$v your attendance in this month is less than 80%.";
							
							
			//add recipient
			$mail -> addAddress("$k");
							
			//finally send email
			if($mail -> Send())
			{
			}
			else
			{
				
			}
			$mail -> smtpClose();	
		}
	}
	else{
		
	}
?>